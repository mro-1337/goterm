package main

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestHostResize(t *testing.T) {
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	p.Feed([]byte("hello\x1b[25;1Hbottom"))
	got := 0
	p.ResizeReq = func(c, r int) { got = c*1000 + r; s.Resize(c, r, modeFontH(c, r)) }
	p.Feed([]byte("\x1b[8;50;132t"))
	if got != 132050 || s.Cols != 132 || s.Rows != 50 || s.CH != 8 {
		t.Fatalf("resize: %d %dx%d ch%d", got, s.Cols, s.Rows, s.CH)
	}
	if s.Cells[0].Ch != 'h' || s.Cells[24*132].Ch != 'b' {
		t.Fatal("content lost")
	}
	p.Feed([]byte("\x1b[8;25;80t"))
	if s.Cols != 80 || s.Rows != 25 {
		t.Fatal("shrink")
	}
	p.Feed([]byte("\x1b[8;30;0t")) // 0 = keep columns
	if s.Cols != 80 || s.Rows != 30 {
		t.Fatalf("keep %dx%d", s.Cols, s.Rows)
	}
	p.ResizeReq = nil
	p.Feed([]byte("\x1b[8;50;132t"))
	if s.Cols != 80 {
		t.Fatal("ignored request applied")
	}
}

func TestPruneCache(t *testing.T) {
	d := t.TempDir()
	now := time.Now()
	for i, n := range []string{"a", "b", "c"} {
		f := filepath.Join(d, n)
		os.WriteFile(f, make([]byte, 100), 0o644)
		os.Chtimes(f, now.Add(time.Duration(i-10)*time.Hour), now.Add(time.Duration(i-10)*time.Hour))
	}
	pruneCache(d, 200)
	if _, err := os.Stat(filepath.Join(d, "a")); err == nil {
		t.Fatal("oldest kept")
	}
	if _, err := os.Stat(filepath.Join(d, "c")); err != nil {
		t.Fatal("newest removed")
	}
}

func TestCacheStartup(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	os.MkdirAll(filepath.Join(cacheRoot(), "h_1"), 0o755)
	f := filepath.Join(cacheRoot(), "h_1", "x.wav")
	os.WriteFile(f, []byte("x"), 0o644)
	cacheStartup(&Config{CacheClear: false, CacheMaxMB: 500})
	if _, err := os.Stat(f); err != nil {
		t.Fatal("removed when clear off")
	}
	cacheStartup(&Config{CacheClear: true})
	if _, err := os.Stat(f); err == nil {
		t.Fatal("not cleared")
	}
	c := newDefaultConfig()
	if c.CacheMaxMB != 500 || !c.CacheClear {
		t.Fatal("defaults")
	}
}
