module github.com/jfreymuth/oggvorbis

go 1.15

require github.com/jfreymuth/vorbis v0.0.0
