package main

import (
	"bytes"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func TestTextPrep(t *testing.T) {
	sauce := append([]byte("\x1a"), make([]byte, 128)...)
	copy(sauce[1:], "SAUCE00")
	ans := append([]byte("\x1b[31mHi\x1b[0m\r\n"), sauce...)
	if got := stripSauce(ans); string(got) != "\x1b[31mHi\x1b[0m\r\n" {
		t.Fatalf("sauce: %q", got)
	}
	if got := asciiPrepare([]byte("a\nb\r\nc\n"), false); string(got) != "a\r\nb\r\nc\r\n" {
		t.Fatalf("crlf: %q", got)
	}
	if got := asciiPrepare([]byte("café ▒\n"), false); string(got) != "caf\x82 \xb1\r\n" {
		t.Fatalf("cp437: %q", got)
	}
	if got := asciiPrepare([]byte("café\n"), true); string(got) != "café\r\n" {
		t.Fatalf("utf8 host: %q", got)
	}
	if n := len(textChunks(make([]byte, 2500), true)); n != 3 {
		t.Fatal(n)
	}
}

func TestTextUploadEndToEnd(t *testing.T) {
	setupPlat()
	a := NewApp(newDefaultConfig())
	var mu sync.Mutex
	var got []byte
	h, p := fakeBBS(t, func(c net.Conn) {
		c.Write([]byte("ready\r\n"))
		go func() {
			buf := make([]byte, 4096)
			for {
				n, err := c.Read(buf)
				mu.Lock()
				got = append(got, buf[:n]...)
				mu.Unlock()
				if err != nil {
					return
				}
			}
		}()
		time.Sleep(4 * time.Second)
		io.Copy(io.Discard, c)
	})
	altQ(a)
	chr(a, fmt.Sprintf("%s %d", h, p))
	key(a, KeyEnter)
	waitFor(t, "connected", 3*time.Second, func() bool {
		a.mu.Lock()
		defer a.mu.Unlock()
		return a.sess != nil && !a.sess.dialing && a.sess.conn != nil
	})
	dir := t.TempDir()
	f1 := filepath.Join(dir, "a.txt")
	f2 := filepath.Join(dir, "b.ans")
	os.WriteFile(f1, []byte("one\ntwo\n"), 0o644)
	raw := append([]byte("\x1b[1;32mX\xff\n"), bytes.Repeat([]byte("z"), 3000)...)
	os.WriteFile(f2, raw, 0o644)
	a.mu.Lock()
	s := a.sess
	a.mu.Unlock()
	s.jobs <- func() { s.doTextUpload([]string{f1}, false) }
	s.jobs <- func() { s.doTextUpload([]string{f2}, true) }
	// telnet doubles a 0xFF data byte (IAC escaping)
	wire := bytes.Replace(raw, []byte{0xff}, []byte{0xff, 0xff}, 1)
	want := append([]byte("one\r\ntwo\r\n"), wire...)
	waitFor(t, "bytes received", 3*time.Second, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return len(got) >= len(want)
	})
	mu.Lock()
	defer mu.Unlock()
	if !bytes.Equal(got, want) {
		t.Fatalf("got %d bytes, want %d\n%q", len(got), len(want), got[:minInt(len(got), 60)])
	}
}

