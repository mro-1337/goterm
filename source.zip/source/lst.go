package main

import (
	"bufio"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

// The dialing directory is stored in goterm.lst, an INI file in the same
// style as SyncTERM's syncterm.lst (one [Name] section per entry), with a
// few extra keys. ImportSyncTermLst reads either flavour.

func fileExists(p string) bool { _, err := os.Stat(p); return err == nil }

func lstClean(s string) string {
	return strings.NewReplacer("\r", " ", "\n", " ").Replace(s)
}

func writeLst(w io.Writer, ents []DialEntry) error {
	bw := bufio.NewWriter(w)
	for _, e := range ents {
		fmt.Fprintf(bw, "[%s]\n", lstClean(e.Name))
		kv := func(k, v string) {
			if v != "" {
				fmt.Fprintf(bw, "\t%s=%s\n", k, lstClean(v))
			}
		}
		flag := func(k string, b bool) {
			if b {
				fmt.Fprintf(bw, "\t%s=1\n", k)
			}
		}
		kv("Address", e.Host)
		fmt.Fprintf(bw, "\tPort=%d\n", e.Port)
		ct := map[string]string{"ssh": "SSH", "rlogin": "RLogin", "raw": "Raw"}[e.Conn]
		if ct == "" {
			ct = "Telnet"
		}
		kv("ConnectionType", ct)
		kv("UserName", e.User)
		kv("Password", e.Password)
		kv("Comment", e.Notes)
		fmt.Fprintf(bw, "\tMusic=%d\n", e.Music)
		kv("TermType", e.Term)
		kv("ScreenMode", e.Mode)
		flag("UTF8", e.UTF8)
		flag("BSDel", e.BSDel)
		flag("NoSound", e.NoSound)
		flag("NoResize", e.NoResize)
		kv("LastConnected", e.Last)
		if e.Count > 0 {
			fmt.Fprintf(bw, "\tCount=%d\n", e.Count)
		}
		kv("UploadPath", e.Uploads)
		bw.WriteString("\n")
	}
	return bw.Flush()
}

func writeLstFile(path string, ents []DialEntry) error {
	tmp := path + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	if err := writeLst(f, ents); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func parseLst(r io.Reader) ([]DialEntry, error) {
	var out []DialEntry
	var cur *DialEntry
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64*1024), 1<<20)
	for sc.Scan() {
		ln := strings.TrimSpace(strings.TrimPrefix(sc.Text(), "\ufeff"))
		if strings.HasPrefix(ln, "[") && strings.HasSuffix(ln, "]") {
			out = append(out, DialEntry{Name: ln[1 : len(ln)-1], Port: 23, Conn: "telnet", Mode: "80x25"})
			cur = &out[len(out)-1]
			continue
		}
		if cur == nil {
			continue
		}
		k, v, ok := strings.Cut(ln, "=")
		if !ok {
			continue
		}
		k, v = strings.ToLower(strings.TrimSpace(k)), strings.TrimSpace(v)
		b := v == "1" || strings.EqualFold(v, "true") || strings.EqualFold(v, "yes")
		switch k {
		case "address":
			cur.Host = v
		case "port":
			cur.Port, _ = strconv.Atoi(v)
		case "connectiontype":
			switch strings.ToLower(v) {
			case "raw", "ssh", "rlogin", "telnet":
				cur.Conn = strings.ToLower(v)
			default:
				cur.Conn = "telnet"
			}
		case "username":
			cur.User = v
		case "password":
			cur.Password = v
		case "comment":
			cur.Notes = v
		case "music":
			cur.Music, _ = strconv.Atoi(v)
		case "termtype":
			cur.Term = v
		case "screenmode":
			for _, m := range screenModes {
				if m.Name == v {
					cur.Mode = v
				}
			}
		case "utf8":
			cur.UTF8 = b
		case "bsdel":
			cur.BSDel = b
		case "nosound":
			cur.NoSound = b
		case "noresize":
			cur.NoResize = b
		case "lastconnected":
			if _, err := time.Parse("2006-01-02 15:04", v); err == nil {
				cur.Last = v
			}
		case "count":
			cur.Count, _ = strconv.Atoi(v)
		case "uploadpath":
			cur.Uploads = v
		}
	}
	// Drop sections that have no address (not a usable entry).
	ok := out[:0]
	for _, e := range out {
		if e.Host != "" {
			if e.Port == 0 {
				e.Port = defaultPort(e.Conn)
			}
			ok = append(ok, e)
		}
	}
	return ok, sc.Err()
}

// ReadLstFile loads a goterm.lst / syncterm.lst file.
func ReadLstFile(path string) ([]DialEntry, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return parseLst(f)
}

// ImportSyncTermLst reads a SyncTERM "syncterm.lst" (or goterm.lst) file.
func ImportSyncTermLst(path string) ([]DialEntry, error) { return ReadLstFile(path) }

// FetchLst downloads and parses a directory list from an http(s) URL.
func FetchLst(raw string) ([]DialEntry, error) {
	raw = strings.TrimSpace(raw)
	if !strings.Contains(raw, "://") {
		raw = "https://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return nil, fmt.Errorf("Enter a web address starting with http:// or https://")
	}
	cl := &http.Client{Timeout: 30 * time.Second}
	resp, err := cl.Get(u.String())
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("The server answered: %s", resp.Status)
	}
	ents, err := parseLst(io.LimitReader(resp.Body, 8<<20))
	if err != nil {
		return nil, err
	}
	if len(ents) == 0 {
		return nil, fmt.Errorf("No entries found. The page must be a syncterm.lst / goterm.lst style list.")
	}
	return ents, nil
}

func entryKey(e DialEntry) string {
	c := e.Conn
	if c == "" {
		c = "telnet"
	}
	return strings.ToLower(strings.TrimSpace(e.Host)) + "|" + strconv.Itoa(e.Port) + "|" + c
}

// dedupe removes entries with the same address, port and connection type,
// keeping the first and merging in the best call history. It returns the
// number removed.
func (c *Config) dedupe() int {
	idx := map[string]int{}
	out := c.Entries[:0:0]
	removed := 0
	for _, e := range c.Entries {
		k := entryKey(e)
		if i, ok := idx[k]; ok {
			d := &out[i]
			if e.Last > d.Last {
				d.Last = e.Last
			}
			d.Count += e.Count
			if d.Notes == "" {
				d.Notes = e.Notes
			}
			if d.User == "" {
				d.User, d.Password = e.User, e.Password
			}
			removed++
			continue
		}
		idx[k] = len(out)
		out = append(out, e)
	}
	c.Entries = out
	return removed
}

// addEntries appends entries that are not already in the directory and
// returns how many were added and how many skipped as duplicates.
func (c *Config) addEntries(ents []DialEntry) (added, dup int) {
	have := map[string]bool{}
	for _, e := range c.Entries {
		have[entryKey(e)] = true
	}
	for _, e := range ents {
		k := entryKey(e)
		if have[k] {
			dup++
			continue
		}
		have[k] = true
		c.Entries = append(c.Entries, e)
		added++
	}
	return
}

// SortEntries orders the directory per DirSort: "name", "last" (most
// recent call first; never-called entries last, by name) or "none".
func (c *Config) SortEntries() {
	lower := func(i int) string { return strings.ToLower(c.Entries[i].Name) }
	switch c.DirSort {
	case "none":
	case "last":
		sort.SliceStable(c.Entries, func(i, j int) bool {
			a, b := c.Entries[i].Last, c.Entries[j].Last
			if a != b {
				return a > b
			}
			return lower(i) < lower(j)
		})
	default:
		sort.SliceStable(c.Entries, func(i, j int) bool { return lower(i) < lower(j) })
	}
}

var _ = filepath.Join
