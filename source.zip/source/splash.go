package main

import (
	"math"
	"time"
)

// Start-up logo: drawn once as a small image, shown over the dialing
// directory and faded out.

const (
	splashIn   = 300 * time.Millisecond
	splashHold = 2200 * time.Millisecond
	splashEnd  = 3200 * time.Millisecond
)

var pixGlyphs = map[byte][7]string{
	'G': {".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".###."},
	'O': {".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."},
	'T': {"#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."},
	'E': {"#####", "#....", "#....", "####.", "#....", "#....", "#####"},
	'R': {"####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"},
	'M': {"#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"},
}

type logoImg struct {
	w, h int
	pix  []float32 // premultiplied RGBA, 4 per pixel
}

func sdfRRect(px, py, hx, hy, r float64) float64 {
	qx, qy := math.Abs(px)-hx+r, math.Abs(py)-hy+r
	return math.Hypot(math.Max(qx, 0), math.Max(qy, 0)) + math.Min(math.Max(qx, qy), 0) - r
}

func segDist(px, py, ax, ay, bx, by float64) float64 {
	dx, dy := bx-ax, by-ay
	t := ((px-ax)*dx + (py-ay)*dy) / (dx*dx + dy*dy)
	t = math.Max(0, math.Min(1, t))
	return math.Hypot(px-(ax+t*dx), py-(ay+t*dy))
}

// logoSample returns the colour at a point of the 500x130 logo space.
// emit marks light-emitting parts (they get a glow).
func logoSample(ux, uy float64) (r, g, b, a float64, emit bool) {
	const gr, gg, gb = 0x2d / 255.0, 0xff / 255.0, 0x6e / 255.0
	ix, iy := ux-8, uy-9
	if ix >= -2 && ix <= 114 && iy >= -2 && iy <= 114 {
		d := sdfRRect(ix-56, iy-56, 52, 52, 20)
		if d <= 3 {
			if d > -3 {
				return 0xc9 / 255.0, 0xcd / 255.0, 0xdd / 255.0, 1, false
			}
			if segDist(ix, iy, 30, 48, 52, 68) <= 5.5 || segDist(ix, iy, 52, 68, 30, 88) <= 5.5 ||
				sdfRRect(ix-74, iy-84.5, 14, 4.5, 2) <= 0 {
				return gr, gg, gb, 1, true
			}
			for i, c := range [][3]float64{{0xff, 0x5f, 0x57}, {0xfe, 0xbc, 0x2e}, {0x28, 0xc8, 0x40}} {
				if math.Hypot(ix-float64(24+16*i), iy-21) <= 5 {
					return c[0] / 255, c[1] / 255, c[2] / 255, 1, false
				}
			}
			if iy < 28 {
				return 0x24 / 255.0, 0x2a / 255.0, 0x38 / 255.0, 1, false
			}
			base := 0x0f / 255.0
			if iy >= 36 && math.Mod(iy-36, 5) < 1 {
				base += 0.05
			}
			return base, base + 0.012, base + 0.03, 1, false
		}
		return 0, 0, 0, 0, false
	}
	wx, wy := ux-136, uy-30
	if wx >= 0 && wy >= 0 && wy < 70 && wx < 350 {
		col, row := int(wx/10), int(wy/10)
		if math.Mod(wx, 10) < 8.6 && math.Mod(wy, 10) < 8.6 && col%6 < 5 && col/6 < 6 {
			ch := "GOTERM"[col/6]
			if pixGlyphs[ch][row][col%6] == '#' {
				if col/6 < 2 {
					return gr, gg, gb, 1, true
				}
				return 0.95, 0.96, 0.98, 1, true
			}
		}
	}
	return 0, 0, 0, 0, false
}

func boxBlur(src []float32, w, h, rad int) []float32 {
	tmp := make([]float32, len(src))
	dst := make([]float32, len(src))
	n := float32(2*rad + 1)
	for y := 0; y < h; y++ {
		for c := 0; c < 4; c++ {
			var sum float32
			for x := -rad; x <= rad; x++ {
				if x >= 0 && x < w {
					sum += src[(y*w+x)*4+c]
				}
			}
			for x := 0; x < w; x++ {
				tmp[(y*w+x)*4+c] = sum / n
				if x+rad+1 < w {
					sum += src[(y*w+x+rad+1)*4+c]
				}
				if x-rad >= 0 {
					sum -= src[(y*w+x-rad)*4+c]
				}
			}
		}
	}
	for x := 0; x < w; x++ {
		for c := 0; c < 4; c++ {
			var sum float32
			for y := -rad; y <= rad; y++ {
				if y >= 0 && y < h {
					sum += tmp[(y*w+x)*4+c]
				}
			}
			for y := 0; y < h; y++ {
				dst[(y*w+x)*4+c] = sum / n
				if y+rad+1 < h {
					sum += tmp[((y+rad+1)*w+x)*4+c]
				}
				if y-rad >= 0 {
					sum -= tmp[((y-rad)*w+x)*4+c]
				}
			}
		}
	}
	return dst
}

func renderLogo(width int) *logoImg {
	if width < 120 {
		width = 120
	}
	sc := float64(width) / 500
	pad := int(10 * sc)
	w, h := width+2*pad, int(130*sc)+2*pad
	const ss = 3
	base := make([]float32, w*h*4)
	emis := make([]float32, w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			var sr, sg, sb, sa, er, eg, eb, ea float64
			for j := 0; j < ss; j++ {
				for i := 0; i < ss; i++ {
					ux := (float64(x-pad) + (float64(i)+0.5)/ss) / sc
					uy := (float64(y-pad) + (float64(j)+0.5)/ss) / sc
					r, g, b, a, em := logoSample(ux, uy)
					sr, sg, sb, sa = sr+r*a, sg+g*a, sb+b*a, sa+a
					if em {
						er, eg, eb, ea = er+r, eg+g, eb+b, ea+1
					}
				}
			}
			k := (y*w + x) * 4
			n := float64(ss * ss)
			base[k], base[k+1], base[k+2], base[k+3] = float32(sr/n), float32(sg/n), float32(sb/n), float32(sa/n)
			emis[k], emis[k+1], emis[k+2], emis[k+3] = float32(er/n), float32(eg/n), float32(eb/n), float32(ea/n)
		}
	}
	rad := int(3*sc) + 1
	glow := boxBlur(boxBlur(emis, w, h, rad), w, h, rad)
	for i := 0; i < len(base); i += 4 {
		ga := glow[i+3] * 0.9
		// additive light on top of the crisp shapes
		for c := 0; c < 3; c++ {
			v := base[i+c] + glow[i+c]*0.9
			if v > 1 {
				v = 1
			}
			base[i+c] = v
		}
		a := base[i+3] + ga*(1-base[i+3])
		if a > 1 {
			a = 1
		}
		base[i+3] = a
	}
	return &logoImg{w, h, base}
}

// StartSplash shows the logo when the first frame is drawn.
func (a *App) StartSplash() {
	a.mu.Lock()
	defer a.mu.Unlock()
	if !a.cfg.NoSplash {
		a.splashPending = true
	}
}

func (a *App) splashActive() bool { return a.splashPending || !a.splashStart.IsZero() }

func (a *App) splashSkip() bool {
	if !a.splashActive() {
		return false
	}
	a.splashPending, a.splashStart = false, time.Time{}
	a.dirty = true
	return true
}

// splashAlpha is the logo opacity now (0 = finished).
func (a *App) splashAlpha() float64 {
	if a.splashPending {
		a.splashPending, a.splashStart = false, time.Now()
	}
	if a.splashStart.IsZero() {
		return 0
	}
	t := time.Since(a.splashStart)
	switch {
	case t >= splashEnd:
		a.splashStart = time.Time{}
		a.dirty = true
		return 0
	case t < splashIn:
		return float64(t) / float64(splashIn)
	case t < splashHold:
		return 1
	}
	return 1 - float64(t-splashHold)/float64(splashEnd-splashHold)
}

// overlaySplash dims body (w x h pixels) and draws the logo over it.
func (a *App) overlaySplash(body []uint32, w, h int, alpha float64) {
	if a.logo == nil || a.logoW != w {
		a.logo, a.logoW = renderLogo(int(float64(w)*0.7)), w
	}
	k := float32(alpha)
	inv := 1 - k
	for i, p := range body {
		r := float32(p>>16&255) * inv
		g := float32(p>>8&255) * inv
		b := float32(p&255) * inv
		body[i] = 0xFF000000 | uint32(r)<<16 | uint32(g)<<8 | uint32(b)
	}
	L := a.logo
	x0, y0 := (w-L.w)/2, h*28/100-L.h/2
	for y := 0; y < L.h; y++ {
		dy := y0 + y
		if dy < 0 || dy >= h {
			continue
		}
		for x := 0; x < L.w; x++ {
			dx := x0 + x
			if dx < 0 || dx >= w {
				continue
			}
			s := (y*L.w + x) * 4
			ca := L.pix[s+3] * k
			if ca <= 0 {
				continue
			}
			p := body[dy*w+dx]
			r := float32(p>>16&255)*(1-ca) + L.pix[s]*255*k
			g := float32(p>>8&255)*(1-ca) + L.pix[s+1]*255*k
			b := float32(p&255)*(1-ca) + L.pix[s+2]*255*k
			body[dy*w+dx] = 0xFF000000 | clamp255(r)<<16 | clamp255(g)<<8 | clamp255(b)
		}
	}
	// tagline and version in the CP437 font, centred under the logo
	f := fontForHeight(a.term.CH)
	scale := w / 640
	if scale < 1 {
		scale = 1
	}
	ty := y0 + L.h + f.H*scale
	a.splashText(body, w, h, ty, "A BBS terminal for Windows, Linux and Android", 0x9aa0a6, k, f, scale)
	a.splashText(body, w, h, ty+f.H*scale*2, "version "+Version, 0x2dff6e, k, f, scale)
}

func clamp255(v float32) uint32 {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return uint32(v)
}

func (a *App) splashText(body []uint32, w, h, y int, s string, col uint32, k float32, f *Font, scale int) {
	tw := len(s) * f.W * scale
	x0 := (w - tw) / 2
	for i := 0; i < len(s); i++ {
		for row := 0; row < f.H; row++ {
			bits := f.Data[int(s[i])*f.H+row]
			for c := 0; c < f.W; c++ {
				if bits&(0x80>>uint(c)) == 0 {
					continue
				}
				for sy := 0; sy < scale; sy++ {
					for sx := 0; sx < scale; sx++ {
						dx, dy := x0+(i*f.W+c)*scale+sx, y+row*scale+sy
						if dx < 0 || dx >= w || dy < 0 || dy >= h {
							continue
						}
						p := body[dy*w+dx]
						r := float32(p>>16&255)*(1-k) + float32(col>>16&255)*k
						g := float32(p>>8&255)*(1-k) + float32(col>>8&255)*k
						b := float32(p&255)*(1-k) + float32(col&255)*k
						body[dy*w+dx] = 0xFF000000 | clamp255(r)<<16 | clamp255(g)<<8 | clamp255(b)
					}
				}
			}
		}
	}
}
