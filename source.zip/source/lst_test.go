package main

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestLstRoundTripAndMigration(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", dir)
	t.Setenv("HOME", dir)
	c := LoadConfig()
	if !fileExists(filepath.Join(dir, "GoTerm", "goterm.lst")) {
		t.Fatal("goterm.lst not created on first run")
	}
	c.Entries = []DialEntry{{Name: "A", Host: "a.example", Port: 2323, Conn: "ssh", User: "u", Notes: "hi", Mode: "80x50", Term: "ansi", UTF8: true, NoResize: true, Last: "2026-10-01 10:00", Count: 3}}
	if err := c.Save(); err != nil {
		t.Fatal(err)
	}
	c2 := LoadConfig()
	if len(c2.Entries) != 1 || c2.Entries[0] != c.Entries[0] {
		t.Fatalf("round trip: %+v", c2.Entries)
	}
}

func TestDedupeSortWeb(t *testing.T) {
	c := newDefaultConfig()
	c.Entries = []DialEntry{
		{Name: "B", Host: "x.com", Port: 23, Conn: "telnet", Last: "2026-01-01 00:00", Count: 1},
		{Name: "A", Host: "X.com", Port: 23, Conn: "telnet", Last: "2026-02-01 00:00", Count: 2},
		{Name: "C", Host: "x.com", Port: 22, Conn: "ssh"},
	}
	if n := c.dedupe(); n != 1 || len(c.Entries) != 2 || c.Entries[0].Count != 3 || c.Entries[0].Last != "2026-02-01 00:00" {
		t.Fatalf("dedupe %d %+v", n, c.Entries)
	}
	c.Entries = append(c.Entries, DialEntry{Name: "Z", Host: "z.com", Port: 23, Conn: "telnet", Last: "2026-05-01 00:00"})
	c.DirSort = "name"
	c.SortEntries()
	if c.Entries[0].Name != "B" || c.Entries[2].Name != "Z" {
		t.Fatalf("name sort %+v", c.Entries)
	}
	c.DirSort = "last"
	c.SortEntries()
	if c.Entries[0].Name != "Z" || c.Entries[2].Name != "C" {
		t.Fatalf("last sort %+v", c.Entries)
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/bad" {
			w.Write([]byte("<html>nope</html>"))
			return
		}
		w.Write([]byte("[Foo BBS]\n\tAddress=foo.example\n\tPort=2300\n\tConnectionType=Telnet\n[Z again]\n\tAddress=z.com\n\tPort=23\n"))
	}))
	defer srv.Close()
	ents, err := FetchLst(srv.URL + "/list.lst")
	if err != nil || len(ents) != 2 {
		t.Fatal(err, ents)
	}
	if add, dup := c.addEntries(ents); add != 1 || dup != 1 {
		t.Fatal(add, dup)
	}
	if _, err := FetchLst(srv.URL + "/bad"); err == nil {
		t.Fatal("expected error")
	}
	if _, err := FetchLst("ftp://x"); err == nil || !strings.Contains(err.Error(), "http") {
		t.Fatal("scheme")
	}
}
