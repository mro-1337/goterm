package main

import (
	"image"
	"image/color"
	"image/png"
	"os"
	"testing"
	"time"
)

func shotPNG(t *testing.T, a *App, name string) {
	fb, w, h := a.Frame()
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for i, p := range fb[:w*h] {
		img.Set(i%w, i/w, color.RGBA{uint8(p >> 16), uint8(p >> 8), uint8(p), 255})
	}
	f, _ := os.Create(name)
	png.Encode(f, img)
	f.Close()
}

func TestShots(t *testing.T) {
	if os.Getenv("SHOTS") == "" {
		t.Skip()
	}
	a := NewApp(newDefaultConfig())
	theApp = a
	a.settings()
	shotPNG(t, a, "/tmp/s1.png")
	a.modals = []Modal{a.dir}
	a.showHelp()
	shotPNG(t, a, "/tmp/s2.png")
	a.modals = []Modal{a.dir}
	a.importURL()
	plat.Clipboard = func() string { return "https://example.com/some/very/long/path/to/the/bbs/list/directory/syncterm.lst" }
	a.modals[len(a.modals)-1].Key(a, KeyEvent{Ch: 22, Ctrl: true})
	shotPNG(t, a, "/tmp/s3.png")
}

func TestSplashShot(t *testing.T) {
	if os.Getenv("SHOTS") == "" {
		t.Skip()
	}
	a := NewApp(newDefaultConfig())
	theApp = a
	a.StartSplash()
	a.Frame()
	a.splashStart = a.splashStart.Add(-1 * time.Second)
	shotPNG(t, a, "/tmp/sp1.png")
	a.splashStart = a.splashStart.Add(-1700 * time.Millisecond)
	shotPNG(t, a, "/tmp/sp2.png")
}
