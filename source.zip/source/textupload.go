package main

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"unicode/utf8"

	"goterm/zmodem"
)

// Text uploads, like SyncTERM's "ASCII" and "Raw" upload protocols: the
// file is simply sent to the host, no error checking.
//
//	ASCII  sends text line by line and makes every line end in CR LF.
//	Raw    sends the bytes exactly as they are (ANSI screens, binary).
//
// While sending, whatever the host sends back is shown on screen, but no
// terminal replies are sent (as in SyncTERM). A SAUCE record at the end of
// an ANSI file (and the Ctrl+Z before it) is not sent.

var uploadNames = append(append([]string(nil), protoNames...), "ASCII (text, lines end in CR LF)", "Raw (byte for byte, e.g. ANSI)")

// stripSauce removes a trailing SAUCE record, its comment block and the
// Ctrl+Z that precedes it.
func stripSauce(b []byte) []byte {
	if len(b) >= 128 && string(b[len(b)-128:len(b)-123]) == "SAUCE" {
		end := len(b) - 128
		if n := int(b[len(b)-128+104]); n > 0 && end >= 5+64*n && string(b[end-5-64*n:end-64*n]) == "COMNT" {
			end -= 5 + 64*n
		}
		if end > 0 && b[end-1] == 0x1A {
			end--
		}
		return b[:end]
	}
	return b
}

// asciiPrepare converts text for an ASCII upload: lone LF becomes CR LF
// and, for hosts that expect CP437, UTF-8 text is converted to CP437.
func asciiPrepare(b []byte, hostUTF8 bool) []byte {
	b = stripSauce(b)
	for len(b) > 0 && b[len(b)-1] == 0x1A {
		b = b[:len(b)-1]
	}
	if !hostUTF8 && utf8.Valid(b) {
		high := false
		for _, c := range b {
			if c >= 0x80 {
				high = true
				break
			}
		}
		if high {
			out := make([]byte, 0, len(b))
			for _, r := range string(b) {
				if c, ok := runeToCP437(r); ok {
					out = append(out, c)
				} else {
					out = append(out, '?')
				}
			}
			b = out
		}
	}
	out := make([]byte, 0, len(b)+len(b)/20)
	for i, c := range b {
		if c == '\n' && (i == 0 || b[i-1] != '\r') {
			out = append(out, '\r')
		}
		out = append(out, c)
	}
	return out
}

// textChunks splits data into the pieces sent one at a time.
func textChunks(data []byte, raw bool) [][]byte {
	var out [][]byte
	for len(data) > 0 {
		n := len(data)
		if raw {
			if n > 1024 {
				n = 1024
			}
		} else {
			n = bytes.IndexByte(data, '\n') + 1
			if n <= 0 {
				n = len(data)
			}
			if n > 1024 {
				n = 1024
			}
		}
		out = append(out, data[:n])
		data = data[n:]
	}
	return out
}

// drain shows anything the host sent while we were uploading.
func (s *Session) drain() error {
	for {
		select {
		case b, ok := <-s.in:
			if !ok {
				return errors.New("the connection was closed")
			}
			s.feed(b)
		default:
			return nil
		}
	}
}

// doTextUpload runs on the session goroutine.
func (s *Session) doTextUpload(paths []string, raw bool) {
	title := "ASCII upload"
	if raw {
		title = "Raw upload"
	}
	s.tracef("=== %s files=%v", title, paths)
	l := s.startXfer(true)
	h := s.hooks()
	s.noReply = true
	var sent []string
	var err error
	for fi, p := range paths {
		var data []byte
		if data, err = os.ReadFile(p); err != nil {
			break
		}
		if raw {
			data = stripSauce(data)
		} else {
			data = asciiPrepare(data, s.entry.UTF8)
		}
		name := filepath.Base(p)
		total := int64(len(data))
		var done int64
		h.Progress(zmodem.Progress{Name: name, Done: 0, Total: total, FileIndex: fi + 1, FileCount: len(paths), Sending: true})
		for _, ch := range textChunks(data, raw) {
			if h.Abort() {
				err = errors.New("cancelled")
				break
			}
			if s.conn == nil {
				err = errors.New("not connected")
				break
			}
			if _, e := s.conn.Write(ch); e != nil {
				err = e
				break
			}
			done += int64(len(ch))
			h.Progress(zmodem.Progress{Name: name, Done: done, Total: total, FileIndex: fi + 1, FileCount: len(paths), Sending: true})
			if err = s.drain(); err != nil {
				break
			}
		}
		if err != nil {
			break
		}
		sent = append(sent, p)
	}
	s.noReply = false
	s.endXfer(l, nil, title, fmt.Sprintf("Sent %d file(s)", len(sent)), sent, err)
}
