package main

import "testing"

func TestFontStateReport(t *testing.T) {
	p := NewParser(NewScreen(80, 25, 8, 16))
	g := ""
	got := &g
	p.Reply = func(b []byte) { g += string(b) }
	p.Feed([]byte("\x1b[=1n"))
	if *got != "\x1b[=1;46;99;0;0;0;0n" {
		t.Fatalf("%q", *got)
	}
	*got = ""
	p.Feed([]byte("\x1b[1;0 D\x1b[=1n"))
	if *got != "\x1b[=1;46;0;0;0;0;0n" {
		t.Fatalf("%q", *got)
	}
	*got = ""
	p.Feed([]byte("\x1b[2;7 D\x1b[=1n"))
	if *got != "\x1b[=1;46;1;0;0;0;0n" {
		t.Fatalf("%q", *got)
	}
}
