package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestPickerShot(t *testing.T) {
	if os.Getenv("SHOTS") == "" {
		t.Skip()
	}
	d := t.TempDir()
	for _, n := range []string{"alpha.txt", "apple.ans", "bravo.zip", "Charlie.doc", "my notes.txt"} {
		os.WriteFile(filepath.Join(d, n), []byte("x"), 0o644)
	}
	os.Mkdir(filepath.Join(d, "docs"), 0o755)
	a := NewApp(newDefaultConfig())
	p := newPicker("Upload - choose file(s)", d, func(*App, []string) {})
	a.push(p)
	for _, r := range "/TXT" {
		p.Key(a, KeyEvent{Ch: r})
	}
	shotPNG(t, a, "/tmp/picker.png")
}
