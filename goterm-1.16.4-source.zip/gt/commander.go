package main

import (
	"errors"
	"fmt"
	"io"
	"net"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// Two-pane file manager in the style of Midnight Commander: local files on
// the left, an FTP / FTPS / SFTP server on the right.

var errAborted = errors.New("cancelled")

func isFileConn(c string) bool { return c == "ftp" || c == "ftps" || c == "ftpes" || c == "sftp" }

type cmdPane struct {
	fs     FileSystem
	dir    string
	ents   []FileInfo // ents[0] is ".." when there is a parent
	sel    int
	top    int
	tagged map[string]bool
	gen    int
	hasUp  bool
}

type Commander struct {
	a      *App
	p      [2]*cmdPane
	act    int
	sort   string
	msg    string
	msgErr bool
	remote FileSystem
	rect   [2][4]int // x, y(list top), w, h per pane
	barY   int
	ta     string // type-ahead prefix
	taAt   time.Time
	lastQ  string // last search text
	// running operation
	busy  bool
	title string
	name  atomic.Value
	done  atomic.Int64
	total atomic.Int64
	abort atomic.Bool
	start time.Time
	files atomic.Int64
	nfile atomic.Int64
}

func newCommander(a *App, remote FileSystem, rdir string) *Commander {
	c := &Commander{a: a, remote: remote, sort: "name"}
	c.name.Store("")
	c.p[0] = &cmdPane{fs: LocalFS{}, tagged: map[string]bool{}}
	c.p[1] = &cmdPane{fs: remote, tagged: map[string]bool{}}
	c.load(c.p[0], a.downDir(), "")
	c.load(c.p[1], rdir, "")
	c.act = 1
	return c
}

// load lists dir for a pane in the background and then shows it.
func (c *Commander) load(p *cmdPane, dir, focus string) {
	p.gen++
	gen := p.gen
	go func() {
		ents, err := p.fs.List(dir)
		a := c.a
		a.mu.Lock()
		defer a.mu.Unlock()
		a.dirty = true
		if gen != p.gen {
			return
		}
		if err != nil && ents == nil {
			c.msg, c.msgErr = err.Error(), true
			if p.dir == "" && len(p.ents) == 0 && dir != "/" && dir != "" {
				c.load(p, p.fs.Parent(dir), "") // initial directory is unusable
			}
			return
		}
		sortInfos(ents, c.sort)
		p.dir = dir
		p.hasUp = dir != "" && p.fs.Parent(dir) != dir
		if _, local := p.fs.(LocalFS); local && dir != "" && p.fs.Parent(dir) == "" {
			p.hasUp = true
		}
		if p.hasUp {
			ents = append([]FileInfo{{Name: "..", Dir: true}}, ents...)
		}
		p.ents = ents
		p.sel, p.top = 0, 0
		p.tagged = map[string]bool{}
		for i, e := range ents {
			if e.Name == focus {
				p.sel = i
			}
		}
		if err != nil {
			c.msg, c.msgErr = err.Error(), true
		}
	}()
}

func (c *Commander) refresh(p *cmdPane) {
	name := ""
	if p.sel < len(p.ents) {
		name = p.ents[p.sel].Name
	}
	c.load(p, p.dir, name)
}

func (c *Commander) cur() *cmdPane   { return c.p[c.act] }
func (c *Commander) other() *cmdPane { return c.p[1-c.act] }

func (c *Commander) enter(p *cmdPane) {
	if p.sel >= len(p.ents) {
		return
	}
	e := p.ents[p.sel]
	if !e.Dir {
		return
	}
	if e.Name == ".." {
		c.load(p, p.fs.Parent(p.dir), pathBase(p.fs, p.dir))
		return
	}
	c.load(p, p.fs.Join(p.dir, e.Name), "")
}

func pathBase(fs FileSystem, dir string) string {
	if _, ok := fs.(LocalFS); ok {
		dir = strings.TrimRight(dir, `/\`)
		if i := strings.LastIndexAny(dir, `/\`); i >= 0 {
			return dir[i+1:]
		}
		return dir
	}
	dir = strings.TrimRight(dir, "/")
	return dir[strings.LastIndex(dir, "/")+1:]
}

// targets returns the tagged entries, or the entry under the cursor.
func (c *Commander) targets(p *cmdPane) []FileInfo {
	var out []FileInfo
	for _, e := range p.ents {
		if p.tagged[e.Name] {
			out = append(out, e)
		}
	}
	if len(out) == 0 && p.sel < len(p.ents) && p.ents[p.sel].Name != ".." {
		out = append(out, p.ents[p.sel])
	}
	return out
}

// ---------------------------------------------------------------- drawing

func fmtSize9(e FileInfo, up bool) string {
	switch {
	case up:
		return "UP--DIR"
	case e.Dir:
		return "SUB-DIR"
	case e.Size >= 10_000_000_000:
		return fmt.Sprintf("%dG", e.Size>>30)
	case e.Size >= 100_000_000:
		return fmt.Sprintf("%dM", e.Size>>20)
	}
	return strconv.FormatInt(e.Size, 10)
}

func fmtMod(t time.Time) string {
	if t.IsZero() {
		return ""
	}
	if time.Since(t) < 180*24*time.Hour && time.Until(t) < 48*time.Hour {
		return t.Format("Jan _2 15:04")
	}
	return t.Format("Jan _2  2006")
}

func (c *Commander) Draw(cv *Canvas) {
	W, H := cv.W(), cv.H()
	cv.fill(0, 0, W, H, ' ', rFrame)
	cv.fill(0, 0, W, 1, ' ', rTitle)
	cv.strClip(1, 0, W-2, "GoTerm Commander   Tab = switch panel   F1 = help   F10 = quit", rTitle)
	half := W / 2
	for i := 0; i < 2; i++ {
		x, w := 0, half
		if i == 1 {
			x, w = half, W-half
		}
		c.drawPane(cv, i, x, 1, w, H-3)
	}
	// info line
	role := rText
	text := c.msg
	if text == "" {
		p := c.cur()
		if p.sel < len(p.ents) && p.ents[p.sel].Name != ".." {
			e := p.ents[p.sel]
			text = e.Name
			if !e.Dir {
				text += "   " + fmtBytes(e.Size)
			}
		}
		n := 0
		var sum int64
		for _, e := range p.ents {
			if p.tagged[e.Name] {
				n++
				sum += e.Size
			}
		}
		if n > 0 {
			text = fmt.Sprintf("%d tagged, %s", n, fmtBytes(sum))
			role = rHilite
		}
	} else if c.msgErr {
		role = rError
	} else {
		role = rHilite
	}
	cv.fill(0, H-2, W, 1, ' ', rFrame)
	cv.strClip(1, H-2, W-2, text, role)
	// F-key bar
	c.barY = H - 1
	x := 0
	cell := W / 10
	labels := []string{"Help", "Sort", "", "Goto", "Copy", "RenMov", "Mkdir", "Delete", "Reload", "Quit"}
	for i, l := range labels {
		cv.str(x, H-1, fmt.Sprintf("%d", i+1), rText)
		cv.strClip(x+len(fmt.Sprintf("%d", i+1)), H-1, cell-len(fmt.Sprintf("%d", i+1)), l, rSelect)
		x += cell
	}
	if c.busy {
		c.drawProgress(cv)
	}
}

func (c *Commander) drawPane(cv *Canvas, i, x, y, w, h int) {
	p := c.p[i]
	b := cv.Border
	role := rFrame
	cv.put(x, y, b[0], role)
	cv.put(x+w-1, y, b[2], role)
	cv.put(x, y+h-1, b[5], role)
	cv.put(x+w-1, y+h-1, b[7], role)
	for k := 1; k < w-1; k++ {
		cv.put(x+k, y, b[1], role)
		cv.put(x+k, y+h-1, b[6], role)
	}
	for k := 1; k < h-1; k++ {
		cv.put(x, y+k, b[3], role)
		cv.put(x+w-1, y+k, b[4], role)
	}
	title := p.dir
	if title == "" {
		title = "(drives)"
	}
	title = " " + p.fs.Name() + ": " + title + " "
	if len(title) > w-4 {
		title = " ..." + title[len(title)-(w-8):]
	}
	trole := rFrame
	if i == c.act {
		trole = rSelect
	}
	cv.str(x+(w-len(title))/2, y, title, trole)

	iw := w - 2
	sizeW, dateW := 8, 13
	showDate := iw >= 34
	nameW := iw - sizeW - 1
	if showDate {
		nameW -= dateW
	}
	hdrY := y + 1
	cv.fill(x+1, hdrY, iw, 1, ' ', rFrame)
	cv.strClip(x+1+(nameW-4)/2, hdrY, 4, "Name", rHilite)
	cv.strClip(x+1+nameW+1, hdrY, sizeW, fmt.Sprintf("%*s", sizeW, "Size"), rHilite)
	if showDate {
		cv.strClip(x+1+nameW+sizeW+2, hdrY, dateW-1, "Modify time", rHilite)
	}
	listH := h - 3
	c.rect[i] = [4]int{x + 1, y + 2, iw, listH}
	if p.sel >= len(p.ents) {
		p.sel = len(p.ents) - 1
	}
	if p.sel < 0 {
		p.sel = 0
	}
	if p.sel < p.top {
		p.top = p.sel
	}
	if p.sel >= p.top+listH {
		p.top = p.sel - listH + 1
	}
	for k := 0; k < listH; k++ {
		ry := y + 2 + k
		cv.fill(x+1, ry, iw, 1, ' ', rFrame)
		cv.put(x+1+nameW, ry, b[3]-0, rFrame) // column rule
		cv.put(x+1+nameW, ry, 0xB3, rFrame)
		if showDate {
			cv.put(x+1+nameW+sizeW+1, ry, 0xB3, rFrame)
		}
		idx := p.top + k
		if idx >= len(p.ents) {
			continue
		}
		e := p.ents[idx]
		r := rText
		if e.Dir {
			r = rFrame
		}
		if p.tagged[e.Name] {
			r = rHilite
		}
		if idx == p.sel && i == c.act {
			r = rSelect
		}
		name := e.Name
		switch {
		case e.Dir:
			name = "/" + name
		case e.Link:
			name = "~" + name
		default:
			name = " " + name
		}
		if r == rSelect {
			cv.fill(x+1, ry, iw, 1, ' ', rSelect)
			cv.put(x+1+nameW, ry, 0xB3, rSelect)
			if showDate {
				cv.put(x+1+nameW+sizeW+1, ry, 0xB3, rSelect)
			}
		}
		cv.strClip(x+1, ry, nameW, name, r)
		cv.strClip(x+1+nameW+1, ry, sizeW, fmt.Sprintf("%*s", sizeW, fmtSize9(e, e.Name == ".." && p.hasUp && idx == 0)), r)
		if showDate && e.Name != ".." {
			cv.strClip(x+1+nameW+sizeW+2, ry, dateW-1, fmtMod(e.Mod), r)
		}
	}
	// scroll hint
	if len(p.ents) > listH {
		cv.put(x+w-1, y+2+(listH-1)*p.top/max(1, len(p.ents)-listH), 0xDB, rFrame)
	}
}

func (c *Commander) drawProgress(cv *Canvas) {
	ix, iy, iw, _ := cv.centered(64, 11, c.title, rFrame)
	cv.strClip(ix, iy+1, iw, "File: "+c.name.Load().(string), rText)
	if n := c.files.Load(); n > 1 {
		cv.strClip(ix, iy+2, iw, fmt.Sprintf("File %d of %d", c.nfile.Load(), n), rText)
	}
	done, total := c.done.Load(), c.total.Load()
	pct := 0
	if total > 0 {
		pct = int(done * 100 / total)
	}
	bw := iw - 6
	for i := 0; i < bw; i++ {
		if i < bw*pct/100 {
			cv.put(ix+i, iy+4, 0xDB, rHilite)
		} else {
			cv.put(ix+i, iy+4, 0xB0, rText)
		}
	}
	cv.str(ix+bw+1, iy+4, fmt.Sprintf("%3d%%", pct), rText)
	el := time.Since(c.start).Seconds()
	rate := 0.0
	if el > 0.3 {
		rate = float64(done) / el
	}
	cv.strClip(ix, iy+5, iw, fmt.Sprintf("%s of %s", fmtBytes(done), fmtBytes(total)), rText)
	eta := "--"
	if rate > 1 && total > done {
		eta = time.Duration(float64(total-done) / rate * float64(time.Second)).Round(time.Second).String()
	}
	cv.strClip(ix, iy+6, iw, fmt.Sprintf("Rate: %s/s    ETA: %s", fmtBytes(int64(rate)), eta), rText)
	cv.strClip(ix, iy+8, iw, "Esc = cancel", rHilite)
}

// ---------------------------------------------------------------- input

func (c *Commander) Key(a *App, ev KeyEvent) {
	if c.busy {
		if ev.Key == KeyEsc || (ev.Ctrl && ev.Ch == 24) {
			c.abort.Store(true)
		}
		return
	}
	c.msg = ""
	p := c.cur()
	n := len(p.ents)
	_, _, _, lh := c.rect[c.act][0], c.rect[c.act][1], c.rect[c.act][2], c.rect[c.act][3]
	switch ev.Key {
	case KeyTab, KeyLeft, KeyRight:
		if ev.Key == KeyLeft {
			c.act = 0
		} else if ev.Key == KeyRight {
			c.act = 1
		} else {
			c.act = 1 - c.act
		}
	case KeyUp:
		p.sel = clampInt(p.sel-1, 0, n-1)
	case KeyDown:
		p.sel = clampInt(p.sel+1, 0, n-1)
	case KeyPgUp:
		p.sel = clampInt(p.sel-lh, 0, n-1)
	case KeyPgDn:
		p.sel = clampInt(p.sel+lh, 0, n-1)
	case KeyHome:
		p.sel = 0
	case KeyEnd:
		p.sel = n - 1
	case KeyEnter:
		c.enter(p)
	case KeyBS:
		if p.hasUp {
			c.load(p, p.fs.Parent(p.dir), pathBase(p.fs, p.dir))
		}
	case KeyIns:
		c.tag(p)
		p.sel = clampInt(p.sel+1, 0, n-1)
	case KeyF1:
		c.help()
	case KeyF2:
		c.cycleSort()
	case KeyF4:
		c.gotoDir()
	case KeyF5:
		c.copy(false)
	case KeyF6:
		c.rename()
	case KeyF7:
		c.mkdir()
	case KeyF8, KeyDel:
		c.del()
	case KeyF9:
		c.refresh(c.p[0])
		c.refresh(c.p[1])
	case KeyF10, KeyEsc:
		c.quit()
	default:
		switch {
		case ev.Ctrl && ev.Ch == 18: // Ctrl+R
			c.refresh(p)
		case ev.Ctrl && ev.Ch == 6:
			c.search()
		case ev.Ctrl || ev.Alt:
		case ev.Ch == ' ':
			c.tag(p)
			p.sel = clampInt(p.sel+1, 0, n-1)
		case ev.Ch == '+':
			for _, e := range p.ents {
				if e.Name != ".." {
					p.tagged[e.Name] = true
				}
			}
		case ev.Ch == '-' || ev.Ch == '\\':
			p.tagged = map[string]bool{}
		case ev.Ch == '/' || (ev.Ctrl && ev.Ch == 6):
			c.search()
		case ev.Ch > ' ' && ev.Ch != '+' && ev.Ch != '-' && ev.Ch != '*' && ev.Ch != '\\':
			p.sel = typeAhead(&c.ta, &c.taAt, ev.Ch, p.sel, len(p.ents), func(i int) string { return p.ents[i].Name })
		case ev.Ch == '*':
			for _, e := range p.ents {
				if e.Name != ".." {
					p.tagged[e.Name] = !p.tagged[e.Name]
				}
			}
		}
	}
}

// search asks for text and moves the cursor to the next entry containing it
// (Enter on the same text again finds the next one).
func (c *Commander) search() {
	p := c.cur()
	c.a.inputBox("Find", "Name contains:", c.lastQ, 200, func(a *App, q string) {
		q = strings.TrimSpace(q)
		if q == "" {
			return
		}
		c.lastQ = q
		lq := strings.ToLower(q)
		n := len(p.ents)
		for k := 1; k <= n; k++ {
			i := (p.sel + k) % n
			if p.ents[i].Name != ".." && strings.Contains(strings.ToLower(p.ents[i].Name), lq) {
				p.sel = i
				return
			}
		}
		c.msg, c.msgErr = "Not found: "+q, true
	})
}

func (c *Commander) tag(p *cmdPane) {
	if p.sel < len(p.ents) && p.ents[p.sel].Name != ".." {
		n := p.ents[p.sel].Name
		if p.tagged[n] {
			delete(p.tagged, n)
		} else {
			p.tagged[n] = true
		}
	}
}

func (c *Commander) Mouse(a *App, ev MouseEvent) {
	if c.busy {
		return
	}
	if ev.Y == c.barY && ev.Down && ev.Button == 0 {
		k := ev.X / max(1, a.term.Cols/10)
		if k >= 0 && k < 10 {
			var key Key = KeyF1 + Key(k)
			if key != KeyF3 {
				c.Key(a, KeyEvent{Key: key})
			}
		}
		return
	}
	for i := 0; i < 2; i++ {
		r := c.rect[i]
		if ev.X < r[0]-1 || ev.X > r[0]+r[2] || ev.Y < r[1]-2 || ev.Y > r[1]+r[3] {
			continue
		}
		p := c.p[i]
		if ev.Wheel != 0 {
			c.act = i
			p.sel = clampInt(p.sel-ev.Wheel*3, 0, len(p.ents)-1)
			return
		}
		if ev.Down && ev.Button == 0 {
			c.act = i
			if ev.Y >= r[1] && ev.Y < r[1]+r[3] {
				if idx := p.top + ev.Y - r[1]; idx < len(p.ents) {
					p.sel = idx
					c.msg = ""
					if ev.Double {
						c.enter(p)
					}
				}
			}
		}
		if ev.Down && ev.Button == 2 && ev.Y >= r[1] && ev.Y < r[1]+r[3] {
			c.act = i
			if idx := p.top + ev.Y - r[1]; idx < len(p.ents) {
				p.sel = idx
				c.tag(p)
			}
		}
		return
	}
}

func (c *Commander) quit() {
	c.a.removeModal(c)
	if len(c.a.modals) == 0 && c.a.sess == nil && c.a.dir != nil {
		c.a.push(c.a.dir) // opened from the command line: go to the dialing directory
	}
	go c.remote.Close()
}

func (c *Commander) help() {
	c.a.message("Commander keys", "Tab / Left / Right  switch panel\nEnter  open folder   Backspace  up\nIns or Space  tag file   +  tag all   -  untag all   *  invert\nF2  sort (name / size / time)\nType letters  jump to a name   /  find (Enter again = next)\nF4  go to a path\nF5  copy to the other panel\nF6  rename (move when files are tagged)\nF7  new folder   F8  delete\nF9  reload   F10 / Esc  quit\nMouse: click, double-click, wheel, right-click tags.")
}

func (c *Commander) cycleSort() {
	next := map[string]string{"name": "size", "size": "time", "time": "name"}
	c.sort = next[c.sort]
	for _, p := range c.p {
		sortInfos(p.ents, c.sort)
		if p.hasUp {
			// keep ".." first
			for i, e := range p.ents {
				if e.Name == ".." {
					p.ents[0], p.ents[i] = p.ents[i], p.ents[0]
					break
				}
			}
		}
	}
	c.msg, c.msgErr = "Sorted by "+c.sort, false
}

func (c *Commander) gotoDir() {
	p := c.cur()
	c.a.inputBox("Go to", "Folder:", p.dir, 300, func(a *App, s string) {
		if s = strings.TrimSpace(s); s != "" {
			c.load(p, s, "")
		}
	})
}

func (c *Commander) mkdir() {
	p := c.cur()
	c.a.inputBox("New folder", "Name:", "", 200, func(a *App, s string) {
		if s = strings.TrimSpace(s); s == "" {
			return
		}
		c.run("Creating folder", func(o *op) error { return p.fs.Mkdir(p.fs.Join(p.dir, s)) }, p)
	})
}

func (c *Commander) rename() {
	p := c.cur()
	t := c.targets(p)
	if len(t) == 0 {
		return
	}
	if len(t) == 1 && !p.tagged[t[0].Name] {
		old := t[0].Name
		c.a.inputBox("Rename", "New name:", old, 200, func(a *App, s string) {
			s = strings.TrimSpace(s)
			if s == "" || s == old {
				return
			}
			c.run("Renaming", func(o *op) error { return p.fs.Rename(p.fs.Join(p.dir, old), p.fs.Join(p.dir, s)) }, p)
		})
		return
	}
	c.copy(true)
}

func (c *Commander) del() {
	p := c.cur()
	t := c.targets(p)
	if len(t) == 0 {
		return
	}
	what := fmt.Sprintf("%d items", len(t))
	if len(t) == 1 {
		what = "\"" + t[0].Name + "\""
	}
	c.a.confirm("Delete", "Delete "+what+" from "+p.fs.Name()+"?", func(a *App) {
		c.run("Deleting", func(o *op) error {
			for _, e := range t {
				if err := o.remove(p.fs, p.fs.Join(p.dir, e.Name), e); err != nil {
					return err
				}
			}
			return nil
		}, p)
	})
}

func (c *Commander) copy(move bool) {
	src, dst := c.cur(), c.other()
	t := c.targets(src)
	if len(t) == 0 {
		return
	}
	verb := "Copy"
	if move {
		verb = "Move"
	}
	exist := 0
	have := map[string]bool{}
	for _, e := range dst.ents {
		have[e.Name] = true
	}
	for _, e := range t {
		if have[e.Name] {
			exist++
		}
	}
	what := fmt.Sprintf("%d items", len(t))
	if len(t) == 1 {
		what = "\"" + t[0].Name + "\""
	}
	q := fmt.Sprintf("%s %s to %s:%s?", verb, what, dst.fs.Name(), dst.dir)
	if exist > 0 {
		q += fmt.Sprintf(" %d existing file(s) will be overwritten.", exist)
	}
	sfs, dfs, sdir, ddir := src.fs, dst.fs, src.dir, dst.dir
	c.a.confirm(verb, q, func(a *App) {
		c.run(verb+" files", func(o *op) error {
			o.scan(sfs, sdir, t)
			for _, e := range t {
				sp := sfs.Join(sdir, e.Name)
				if err := o.copyItem(sfs, sp, e, dfs, dfs.Join(ddir, e.Name), true); err != nil {
					return err
				}
				if move {
					if err := o.remove(sfs, sp, e); err != nil {
						return err
					}
				}
			}
			return nil
		}, src, dst)
	})
}

// ---------------------------------------------------------------- operations

type op struct{ c *Commander }

func (o *op) check() error {
	if o.c.abort.Load() {
		return errAborted
	}
	return nil
}

func (o *op) scan(fs FileSystem, dir string, t []FileInfo) {
	o.c.name.Store("scanning ...")
	var walk func(p string, e FileInfo, top bool)
	walk = func(p string, e FileInfo, top bool) {
		if o.check() != nil {
			return
		}
		if e.Dir {
			if e.Link && !top {
				return
			}
			l, _ := fs.List(p)
			for _, ch := range l {
				walk(fs.Join(p, ch.Name), ch, false)
			}
			return
		}
		o.c.total.Add(e.Size)
		o.c.files.Add(1)
	}
	for _, e := range t {
		walk(fs.Join(dir, e.Name), e, true)
	}
}

func (o *op) remove(fs FileSystem, p string, e FileInfo) error {
	if err := o.check(); err != nil {
		return err
	}
	o.c.name.Store(p)
	if e.Dir && !e.Link {
		l, err := fs.List(p)
		if err != nil {
			return err
		}
		for _, ch := range l {
			if err := o.remove(fs, fs.Join(p, ch.Name), ch); err != nil {
				return err
			}
		}
		return fs.Remove(p, true)
	}
	return fs.Remove(p, false)
}

type countReader struct {
	r io.Reader
	o *op
}

func (cr countReader) Read(p []byte) (int, error) {
	if err := cr.o.check(); err != nil {
		return 0, err
	}
	n, err := cr.r.Read(p)
	cr.o.c.done.Add(int64(n))
	return n, err
}

func (o *op) copyItem(sfs FileSystem, sp string, e FileInfo, dfs FileSystem, dp string, top bool) error {
	if err := o.check(); err != nil {
		return err
	}
	if e.Dir {
		if e.Link && !top {
			return nil
		}
		dfs.Mkdir(dp) // fine if it already exists; a real problem shows on the first file
		l, err := sfs.List(sp)
		if err != nil {
			return err
		}
		for _, ch := range l {
			if err := o.copyItem(sfs, sfs.Join(sp, ch.Name), ch, dfs, dfs.Join(dp, ch.Name), false); err != nil {
				return err
			}
		}
		return nil
	}
	o.c.name.Store(e.Name)
	o.c.nfile.Add(1)
	r, size, err := sfs.Open(sp)
	if err != nil {
		return err
	}
	w, err := dfs.Create(dp)
	if err != nil {
		r.Close()
		return err
	}
	if o.c.files.Load() == 0 && size > 0 {
		o.c.total.Add(size)
	}
	_, err = io.CopyBuffer(w, countReader{r, o}, make([]byte, 64*1024))
	r.Close()
	if cerr := w.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		dfs.Remove(dp, false) // do not leave half a file behind
	}
	return err
}

// run executes fn in the background with the progress box showing, then
// reloads the given panes.
func (c *Commander) run(title string, fn func(o *op) error, reload ...*cmdPane) {
	c.busy, c.title = true, title
	c.abort.Store(false)
	c.done.Store(0)
	c.total.Store(0)
	c.files.Store(0)
	c.nfile.Store(0)
	c.name.Store("")
	c.start = time.Now()
	a := c.a
	finished := make(chan struct{})
	go func() {
		t := time.NewTicker(100 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				a.mu.Lock()
				a.dirty = true
				a.mu.Unlock()
			case <-finished:
				return
			}
		}
	}()
	go func() {
		err := fn(&op{c})
		close(finished)
		a.mu.Lock()
		defer a.mu.Unlock()
		c.busy = false
		for _, p := range reload {
			c.refresh(p)
		}
		switch {
		case err == errAborted:
			c.msg, c.msgErr = "Cancelled.", true
		case err != nil:
			c.msg, c.msgErr = err.Error(), true
			a.errorBox(err.Error())
		default:
			c.msg, c.msgErr = "Done.", false
		}
		a.dirty = true
	}()
}

// ---------------------------------------------------------------- connecting

// openCommander connects in the background and then shows the commander.
func (a *App) openCommander(e DialEntry, idx int) {
	port := e.Port
	if port == 0 {
		port = defaultPort(e.Conn)
	}
	cancelled := false
	wait := &MsgModal{Title: "Connecting", Lines: []string{fmt.Sprintf("Connecting to %s:%d ...", e.Host, port)}, Role: rFrame,
		Buttons: []string{"Cancel"}, OnPick: func(a *App, i int) { cancelled = true }}
	a.push(wait)
	if idx >= 0 {
		a.cfg.Entries[idx].Count++
		a.cfg.Entries[idx].Last = time.Now().Format("2006-01-02 15:04")
		a.cfg.Save()
	}
	askPass := func() (string, error) {
		ch := make(chan string, 1)
		a.mu.Lock()
		a.passwordBox(strings.ToUpper(e.Conn)+" password", "Password for "+orStr(e.User, "anonymous")+"@"+e.Host+":",
			func(a *App, p string) { ch <- p }, func(a *App) { close(ch) })
		a.dirty = true
		a.mu.Unlock()
		p, ok := <-ch
		if !ok {
			return "", errors.New("password entry cancelled")
		}
		return p, nil
	}
	go func() {
		var fs FileSystem
		var rdir string
		var err error
		switch e.Conn {
		case "sftp":
			var s *SFTPFS
			if s, err = DialSFTP(net.JoinHostPort(e.Host, strconv.Itoa(port)), e.User, e.Password, 20*time.Second, askPass); err == nil {
				fs = s
				rdir, _ = s.Getwd()
			}
		default:
			var f *FTPFS
			if f, err = DialFTP(e.Host, port, e.Conn, e.User, e.Password, 20*time.Second, askPass); err == nil {
				fs = f
				rdir, _ = f.Getwd()
			}
		}
		a.mu.Lock()
		defer a.mu.Unlock()
		a.dirty = true
		if cancelled {
			if fs != nil {
				go fs.Close()
			}
			return
		}
		a.removeModal(wait)
		if err != nil {
			a.errorBox(err.Error())
			return
		}
		if e.RemoteDir != "" {
			rdir = e.RemoteDir
		}
		a.push(newCommander(a, fs, rdir))
	}()
}
