package main

import (
	"bytes"
	"errors"
	"image"
	"runtime"

	"goterm/third_party/jxl/core"
	"goterm/third_party/jxl/options"
)

// decodeJXL decodes a JPEG XL codestream or container to an image.
func decodeJXL(b []byte) (img image.Image, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = errors.New("jxl: corrupt image")
		}
	}()
	// Refuse absurd sizes before allocating anything for them.
	opts := &options.JXLOptions{MaxGoroutines: jxlThreads()}
	hdr, err := core.NewJXLDecoder(bytes.NewReader(b), opts).GetImageHeader()
	if err != nil {
		return nil, err
	}
	if hdr.OrientedWidth == 0 || hdr.OrientedHeight == 0 || uint64(hdr.OrientedWidth)*uint64(hdr.OrientedHeight) > 8<<20 {
		return nil, errors.New("jxl: bad image size")
	}
	d := core.NewJXLDecoder(bytes.NewReader(b), opts)
	im, err := d.Decode()
	if err != nil {
		return nil, err
	}
	return im.ToImage()
}

// jxlThreads is how many cores one frame decode may use. A game door streams
// frames as fast as they are consumed, so decoding never idles; using every
// core would starve the rest of the computer. Half the cores (1 to 4) leaves
// the window, the audio and everything else running smoothly.
func jxlThreads() int {
	n := runtime.NumCPU() / 2
	if n < 1 {
		n = 1
	}
	if n > 4 {
		n = 4
	}
	return n
}
