package main

import (
	"strings"
	"testing"
)

// Escape sequences the Synchronet graphics doors send on entry/exit must be
// swallowed silently (no stray characters on screen).
func TestDoorControlStringsSilent(t *testing.T) {
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	var replies []string
	p.Reply = func(b []byte) { replies = append(replies, string(b)) }
	seqs := "\x1bP$q$~\x1b\\" + "\x1b[0$~" + // status line off + DECRQSS
		"\x1b[2J\x1b[H\x1b[?25l\x1b[?7l\x1b[?80l\x1b[?1070l" +
		"\x1b[>0q" + "\x1b[>3p" + "\x1b[c" +
		"\x1b[14t\x1b[16t\x1b[?2;1S\x1b7\x1b[999;999H\x1b[6n\x1b8" +
		"\x1b[?1070h\x1b[?7h\x1b[?25h\x1b[>1p"
	p.Feed([]byte(seqs))
	for y := 0; y < 25; y++ {
		var row strings.Builder
		for x := 0; x < 80; x++ {
			if c := s.Cells[y*80+x].Ch; c != 0 && c != ' ' {
				row.WriteByte(c)
			}
		}
		if row.Len() > 0 {
			t.Errorf("stray text on row %d: %q", y, row.String())
		}
	}
	t.Logf("replies: %q", replies)
}
