package main

import (
	"bytes"
	"errors"
	"image"

	"goterm/third_party/jxl/core"
)

// decodeJXL decodes a JPEG XL codestream or container to an image.
func decodeJXL(b []byte) (img image.Image, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = errors.New("jxl: corrupt image")
		}
	}()
	// Refuse absurd sizes before allocating anything for them.
	hdr, err := core.NewJXLDecoder(bytes.NewReader(b), nil).GetImageHeader()
	if err != nil {
		return nil, err
	}
	if hdr.OrientedWidth == 0 || hdr.OrientedHeight == 0 || uint64(hdr.OrientedWidth)*uint64(hdr.OrientedHeight) > 8<<20 {
		return nil, errors.New("jxl: bad image size")
	}
	d := core.NewJXLDecoder(bytes.NewReader(b), nil)
	im, err := d.Decode()
	if err != nil {
		return nil, err
	}
	return im.ToImage()
}
