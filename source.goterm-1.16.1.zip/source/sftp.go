package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

// SFTP v3 client (draft-ietf-secsh-filexfer-02) over an SSH "sftp" subsystem.
// Requests are matched to replies by id, so reads are pipelined and writes
// are asynchronous, which is what makes it fast on high-latency links.

const (
	fxInit, fxVersion                                  = 1, 2
	fxOpen, fxClose, fxRead, fxWrite, fxLstat, fxFstat = 3, 4, 5, 6, 7, 8
	fxOpendir, fxReaddir, fxRemove, fxMkdir, fxRmdir   = 11, 12, 13, 14, 15
	fxRealpath, fxStat, fxRename                       = 16, 17, 18
	fxStatus, fxHandle, fxData, fxName, fxAttrs        = 101, 102, 103, 104, 105
	flRead, flWrite, flCreat, flTrunc                  = 1, 2, 8, 0x10
	sftpChunk                                          = 32 * 1024
	sftpWindow                                         = 16
)

type sftpReply struct {
	typ  byte
	body []byte
}

type SFTPFS struct {
	cli   *ssh.Client
	sess  *ssh.Session
	in    io.WriteCloser
	wmu   sync.Mutex
	mu    sync.Mutex
	next  uint32
	wait  map[uint32]chan sftpReply
	dead  error
	label string
}

func DialSFTP(addr, user, pass string, timeout time.Duration, askPass func() (string, error)) (*SFTPFS, error) {
	cli, err := sshDial(addr, user, pass, timeout, askPass)
	if err != nil {
		return nil, err
	}
	sess, err := cli.NewSession()
	if err != nil {
		cli.Close()
		return nil, err
	}
	in, err := sess.StdinPipe()
	if err != nil {
		cli.Close()
		return nil, err
	}
	out, err := sess.StdoutPipe()
	if err != nil {
		cli.Close()
		return nil, err
	}
	if err := sess.RequestSubsystem("sftp"); err != nil {
		cli.Close()
		return nil, fmt.Errorf("the server has no sftp subsystem: %w", err)
	}
	host := addr
	if i := strings.LastIndex(host, ":"); i > 0 {
		host = host[:i]
	}
	s := &SFTPFS{cli: cli, sess: sess, in: in, wait: map[uint32]chan sftpReply{}, label: "SFTP " + host}
	if err := s.send(fxInit, binary.BigEndian.AppendUint32(nil, 3)); err != nil {
		cli.Close()
		return nil, err
	}
	typ, _, err := readSFTPPacket(out)
	if err != nil || typ != fxVersion {
		cli.Close()
		return nil, errors.New("bad SFTP handshake")
	}
	go s.reader(out)
	return s, nil
}

func readSFTPPacket(r io.Reader) (byte, []byte, error) {
	var h [5]byte
	if _, err := io.ReadFull(r, h[:]); err != nil {
		return 0, nil, err
	}
	n := binary.BigEndian.Uint32(h[:4])
	if n < 1 || n > 1<<24 {
		return 0, nil, errors.New("bad SFTP packet")
	}
	b := make([]byte, n-1)
	if _, err := io.ReadFull(r, b); err != nil {
		return 0, nil, err
	}
	return h[4], b, nil
}

func (s *SFTPFS) send(typ byte, body []byte) error {
	buf := binary.BigEndian.AppendUint32(nil, uint32(len(body)+1))
	buf = append(buf, typ)
	buf = append(buf, body...)
	s.wmu.Lock()
	defer s.wmu.Unlock()
	_, err := s.in.Write(buf)
	return err
}

func (s *SFTPFS) reader(r io.Reader) {
	for {
		typ, b, err := readSFTPPacket(r)
		if err != nil {
			s.mu.Lock()
			s.dead = err
			for id, c := range s.wait {
				close(c)
				delete(s.wait, id)
			}
			s.mu.Unlock()
			return
		}
		if len(b) < 4 {
			continue
		}
		id := binary.BigEndian.Uint32(b)
		s.mu.Lock()
		c := s.wait[id]
		delete(s.wait, id)
		s.mu.Unlock()
		if c != nil {
			c <- sftpReply{typ, b[4:]}
		}
	}
}

func sstr(b []byte) []byte { return append(binary.BigEndian.AppendUint32(nil, uint32(len(b))), b...) }

// start sends a request and returns the channel its reply will arrive on.
func (s *SFTPFS) start(typ byte, body []byte) (chan sftpReply, error) {
	s.mu.Lock()
	if s.dead != nil {
		err := s.dead
		s.mu.Unlock()
		return nil, err
	}
	s.next++
	id := s.next
	c := make(chan sftpReply, 1)
	s.wait[id] = c
	s.mu.Unlock()
	if err := s.send(typ, append(binary.BigEndian.AppendUint32(nil, id), body...)); err != nil {
		return nil, err
	}
	return c, nil
}

func (s *SFTPFS) await(c chan sftpReply) (sftpReply, error) {
	r, ok := <-c
	if !ok {
		return r, io.ErrUnexpectedEOF
	}
	return r, nil
}

func (s *SFTPFS) do(typ byte, body []byte) (sftpReply, error) {
	c, err := s.start(typ, body)
	if err != nil {
		return sftpReply{}, err
	}
	return s.await(c)
}

func statusErr(r sftpReply) error {
	if r.typ != fxStatus || len(r.body) < 4 {
		return fmt.Errorf("unexpected SFTP reply %d", r.typ)
	}
	code := binary.BigEndian.Uint32(r.body)
	if code == 0 {
		return nil
	}
	if code == 1 {
		return io.EOF
	}
	msg := ""
	if len(r.body) >= 8 {
		n := binary.BigEndian.Uint32(r.body[4:])
		if int(n) <= len(r.body)-8 {
			msg = string(r.body[8 : 8+n])
		}
	}
	if msg == "" {
		msg = [...]string{"ok", "eof", "no such file", "permission denied", "failure", "bad message", "no connection", "connection lost", "unsupported"}[min(code, 8)]
	}
	return errors.New(msg)
}

func (s *SFTPFS) simple(typ byte, body []byte) error {
	r, err := s.do(typ, body)
	if err != nil {
		return err
	}
	return statusErr(r)
}

type sattrs struct {
	size  int64
	perm  uint32
	mtime uint32
}

func parseAttrs(b []byte) (sattrs, []byte, bool) {
	var a sattrs
	if len(b) < 4 {
		return a, nil, false
	}
	fl := binary.BigEndian.Uint32(b)
	b = b[4:]
	take := func(n int) []byte {
		if len(b) < n {
			b = nil
			return nil
		}
		x := b[:n]
		b = b[n:]
		return x
	}
	if fl&1 != 0 {
		if x := take(8); x != nil {
			a.size = int64(binary.BigEndian.Uint64(x))
		}
	}
	if fl&2 != 0 {
		take(8)
	}
	if fl&4 != 0 {
		if x := take(4); x != nil {
			a.perm = binary.BigEndian.Uint32(x)
		}
	}
	if fl&8 != 0 {
		take(4)
		if x := take(4); x != nil {
			a.mtime = binary.BigEndian.Uint32(x)
		}
	}
	if fl&0x80000000 != 0 {
		if x := take(4); x != nil {
			n := int(binary.BigEndian.Uint32(x))
			for i := 0; i < n && b != nil; i++ {
				for j := 0; j < 2; j++ {
					if l := take(4); l != nil {
						take(int(binary.BigEndian.Uint32(l)))
					}
				}
			}
		}
	}
	return a, b, b != nil || fl == 0
}

func (s *SFTPFS) Name() string { return s.label }

func (s *SFTPFS) Getwd() (string, error) {
	r, err := s.do(fxRealpath, sstr([]byte(".")))
	if err != nil {
		return "/", err
	}
	if r.typ != fxName || len(r.body) < 8 {
		return "/", statusErr(r)
	}
	n := binary.BigEndian.Uint32(r.body[4:])
	if int(n) > len(r.body)-8 {
		return "/", errors.New("bad reply")
	}
	return string(r.body[8 : 8+n]), nil
}

func (s *SFTPFS) List(dir string) ([]FileInfo, error) {
	r, err := s.do(fxOpendir, sstr([]byte(dir)))
	if err != nil {
		return nil, err
	}
	if r.typ != fxHandle {
		return nil, statusErr(r)
	}
	h := r.body[4:]
	defer s.simple(fxClose, sstr(h))
	var out []FileInfo
	for {
		r, err := s.do(fxReaddir, sstr(h))
		if err != nil {
			return out, err
		}
		if r.typ == fxStatus {
			if err := statusErr(r); err != io.EOF {
				return out, err
			}
			return out, nil
		}
		if r.typ != fxName || len(r.body) < 4 {
			return out, errors.New("bad READDIR reply")
		}
		cnt := int(binary.BigEndian.Uint32(r.body))
		b := r.body[4:]
		for i := 0; i < cnt; i++ {
			var name string
			for j := 0; j < 2; j++ { // filename, longname
				if len(b) < 4 {
					return out, errors.New("bad READDIR reply")
				}
				n := int(binary.BigEndian.Uint32(b))
				if len(b) < 4+n {
					return out, errors.New("bad READDIR reply")
				}
				if j == 0 {
					name = string(b[4 : 4+n])
				}
				b = b[4+n:]
			}
			a, rest, ok := parseAttrs(b)
			if !ok {
				return out, errors.New("bad attributes")
			}
			b = rest
			if name == "." || name == ".." {
				continue
			}
			fi := FileInfo{Name: name, Size: a.size, Dir: a.perm&0o170000 == 0o040000, Link: a.perm&0o170000 == 0o120000}
			if a.mtime != 0 {
				fi.Mod = time.Unix(int64(a.mtime), 0)
			}
			if fi.Link { // find out what it points at
				if st, err := s.stat(path.Join(dir, name)); err == nil {
					fi.Dir, fi.Size = st.perm&0o170000 == 0o040000, st.size
				}
			}
			out = append(out, fi)
		}
	}
}

func (s *SFTPFS) stat(p string) (sattrs, error) {
	r, err := s.do(fxStat, sstr([]byte(p)))
	if err != nil {
		return sattrs{}, err
	}
	if r.typ != fxAttrs {
		return sattrs{}, statusErr(r)
	}
	a, _, _ := parseAttrs(r.body)
	return a, nil
}

func (s *SFTPFS) openHandle(p string, flags uint32) ([]byte, error) {
	body := append(sstr([]byte(p)), binary.BigEndian.AppendUint32(nil, flags)...)
	body = binary.BigEndian.AppendUint32(body, 0) // empty attrs
	r, err := s.do(fxOpen, body)
	if err != nil {
		return nil, err
	}
	if r.typ != fxHandle {
		return nil, statusErr(r)
	}
	return r.body[4:], nil
}

type sftpReader struct {
	s    *SFTPFS
	h    []byte
	off  uint64 // next offset to request
	pend []chan sftpReply
	buf  []byte
	eof  bool
	err  error
}

func (r *sftpReader) fill() {
	for !r.eof && len(r.pend) < sftpWindow {
		body := append(sstr(r.h), binary.BigEndian.AppendUint64(nil, r.off)...)
		body = binary.BigEndian.AppendUint32(body, sftpChunk)
		c, err := r.s.start(fxRead, body)
		if err != nil {
			r.err = err
			return
		}
		r.pend = append(r.pend, c)
		r.off += sftpChunk
	}
}

func (r *sftpReader) Read(p []byte) (int, error) {
	for len(r.buf) == 0 {
		if r.err != nil {
			return 0, r.err
		}
		if r.eof && len(r.pend) == 0 {
			return 0, io.EOF
		}
		r.fill()
		if len(r.pend) == 0 {
			continue
		}
		c := r.pend[0]
		r.pend = r.pend[1:]
		rep, err := r.s.await(c)
		if err != nil {
			r.err = err
			continue
		}
		switch rep.typ {
		case fxData:
			if len(rep.body) < 4 {
				r.err = errors.New("bad DATA")
				continue
			}
			n := binary.BigEndian.Uint32(rep.body)
			if int(n) > len(rep.body)-4 {
				r.err = errors.New("bad DATA")
				continue
			}
			r.buf = rep.body[4 : 4+n]
			if n < sftpChunk {
				// short read: re-request the gap by restarting the window
				r.restart(n)
			}
		default:
			if e := statusErr(rep); e == io.EOF {
				r.eof = true
				r.pend = nil // everything after EOF is also EOF
			} else {
				r.err = e
			}
		}
	}
	n := copy(p, r.buf)
	r.buf = r.buf[n:]
	return n, nil
}

// restart handles a server that returned fewer bytes than asked for: the
// chunks already requested beyond it are discarded and re-requested from
// the right offset.
func (r *sftpReader) restart(got uint32) {
	for _, c := range r.pend {
		r.s.discard(c)
	}
	consumed := r.off - uint64(len(r.pend))*sftpChunk // offset of the chunk just returned + chunk
	r.pend = nil
	r.off = consumed - sftpChunk + uint64(got)
}

func (s *SFTPFS) discard(c chan sftpReply) { go func() { <-c }() }

func (r *sftpReader) Close() error {
	for _, c := range r.pend {
		r.s.discard(c)
	}
	return r.s.simple(fxClose, sstr(r.h))
}

func (s *SFTPFS) Open(p string) (io.ReadCloser, int64, error) {
	size := int64(-1)
	if a, err := s.stat(p); err == nil {
		size = a.size
	}
	h, err := s.openHandle(p, flRead)
	if err != nil {
		return nil, 0, err
	}
	return &sftpReader{s: s, h: h}, size, nil
}

type sftpWriter struct {
	s    *SFTPFS
	h    []byte
	off  uint64
	pend []chan sftpReply
	err  error
}

func (w *sftpWriter) drain(max int) {
	for len(w.pend) > max {
		rep, err := w.s.await(w.pend[0])
		w.pend = w.pend[1:]
		if err == nil {
			err = statusErr(rep)
		}
		if err != nil && w.err == nil {
			w.err = err
		}
	}
}

func (w *sftpWriter) Write(p []byte) (int, error) {
	total := len(p)
	for len(p) > 0 && w.err == nil {
		n := min(len(p), sftpChunk)
		body := append(sstr(w.h), binary.BigEndian.AppendUint64(nil, w.off)...)
		body = append(body, sstr(p[:n])...)
		c, err := w.s.start(fxWrite, body)
		if err != nil {
			return 0, err
		}
		w.pend = append(w.pend, c)
		w.off += uint64(n)
		p = p[n:]
		w.drain(sftpWindow)
	}
	return total, w.err
}

func (w *sftpWriter) Close() error {
	w.drain(0)
	err := w.s.simple(fxClose, sstr(w.h))
	if w.err != nil {
		return w.err
	}
	return err
}

func (s *SFTPFS) Create(p string) (io.WriteCloser, error) {
	h, err := s.openHandle(p, flWrite|flCreat|flTrunc)
	if err != nil {
		return nil, err
	}
	return &sftpWriter{s: s, h: h}, nil
}

func (s *SFTPFS) Mkdir(p string) error {
	return s.simple(fxMkdir, append(sstr([]byte(p)), 0, 0, 0, 0))
}

func (s *SFTPFS) Remove(p string, dir bool) error {
	if dir {
		return s.simple(fxRmdir, sstr([]byte(p)))
	}
	return s.simple(fxRemove, sstr([]byte(p)))
}

func (s *SFTPFS) Rename(a, b string) error {
	return s.simple(fxRename, append(sstr([]byte(a)), sstr([]byte(b))...))
}

func (s *SFTPFS) Join(dir, name string) string { return path.Join(dir, name) }
func (s *SFTPFS) Parent(dir string) string     { return path.Dir(dir) }
func (s *SFTPFS) Close() error                 { return s.cli.Close() }

var _ = os.ErrNotExist
