package main

import (
	"testing"
)

func TestEraseScreenHomesCursor(t *testing.T) {
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	p.Feed([]byte("login:\r\npassword:\r\n\x1b[40m\x1b[2J\r\nHEAD"))
	if s.CY != 1 || s.Cells[s.idx(0, 1)].Ch != 'H' {
		t.Fatalf("after ESC[2J the next line should be row 1, cursor at row %d", s.CY)
	}
	p.Feed([]byte("\x1b[2J"))
	if s.CX != 0 || s.CY != 0 {
		t.Fatalf("cursor %d,%d", s.CX, s.CY)
	}
}

func TestPgUpScrollOption(t *testing.T) {
	a := NewApp(newDefaultConfig())
	a.cfg.PgScroll = true
	a.startLocal()
	for i := 0; i < 60; i++ {
		a.parser.Feed([]byte("line\r\n"))
	}
	a.modals = nil
	a.OnKey(KeyEvent{Key: KeyPgUp})
	if a.term.ViewOffset == 0 {
		t.Fatal("PgUp did not scroll with the option on")
	}
	a.term.ViewOffset = 0
	a.cfg.PgScroll = false
	a.OnKey(KeyEvent{Key: KeyPgUp})
	if a.term.ViewOffset != 0 {
		t.Fatal("PgUp scrolled with the option off")
	}
}
