#!/usr/bin/env python3
"""Test server for GoTerm's FTP/FTPS/SFTP client tests.
usage: fileserver.py MODE PORT ROOT   (MODE = ftp | ftps | ftpes | sftp)"""
import os, sys, socket, threading, tempfile, subprocess
mode, port, root = sys.argv[1], int(sys.argv[2]), sys.argv[3]

if mode == "sftp":
    import paramiko
    from paramiko import SFTPServer, SFTPServerInterface, SFTPAttributes, SFTPHandle, SFTP_OK, ServerInterface, AUTH_SUCCESSFUL, OPEN_SUCCEEDED
    key = paramiko.RSAKey.generate(2048)
    def real(p): return os.path.join(root, p.lstrip("/"))
    class H(SFTPHandle):
        def stat(self): return SFTPAttributes.from_stat(os.fstat(self.readfile.fileno()))
    class FS(SFTPServerInterface):
        def list_folder(self, path):
            out = []
            for n in os.listdir(real(path)):
                a = SFTPAttributes.from_stat(os.lstat(os.path.join(real(path), n))); a.filename = n; out.append(a)
            return out
        def stat(self, path):
            try: return SFTPAttributes.from_stat(os.stat(real(path)))
            except OSError as e: return SFTPServer.convert_errno(e.errno)
        lstat = stat
        def open(self, path, flags, attr):
            try:
                binary = getattr(os, 'O_BINARY', 0)
                fd = os.open(real(path), flags | binary, 0o644)
            except OSError as e: return SFTPServer.convert_errno(e.errno)
            if flags & os.O_WRONLY: m = 'wb'
            elif flags & os.O_RDWR: m = 'r+b'
            else: m = 'rb'
            f = os.fdopen(fd, m); h = H(flags); h.filename = real(path); h.readfile = f; h.writefile = f; return h
        def remove(self, path):
            try: os.remove(real(path))
            except OSError as e: return SFTPServer.convert_errno(e.errno)
            return SFTP_OK
        def rename(self, a, b):
            try: os.rename(real(a), real(b))
            except OSError as e: return SFTPServer.convert_errno(e.errno)
            return SFTP_OK
        def mkdir(self, path, attr):
            try: os.mkdir(real(path))
            except OSError as e: return SFTPServer.convert_errno(e.errno)
            return SFTP_OK
        def rmdir(self, path):
            try: os.rmdir(real(path))
            except OSError as e: return SFTPServer.convert_errno(e.errno)
            return SFTP_OK
        def canonicalize(self, path):
            return "/" + os.path.normpath("/" + path).lstrip("/") if path not in (".", "") else "/"
    class SI(ServerInterface):
        def check_auth_password(self, u, p): return AUTH_SUCCESSFUL if (u, p) == ("bob", "pw") else paramiko.AUTH_FAILED
        def get_allowed_auths(self, u): return "password"
        def check_channel_request(self, k, c): return OPEN_SUCCEEDED
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port)); s.listen(5); print("ready", flush=True)
    def serve(c):
        t = paramiko.Transport(c); t.add_server_key(key)
        t.set_subsystem_handler("sftp", SFTPServer, FS); t.start_server(server=SI())
    while True:
        c, _ = s.accept(); threading.Thread(target=serve, args=(c,), daemon=True).start()
else:
    from pyftpdlib.authorizers import DummyAuthorizer
    from pyftpdlib.handlers import FTPHandler, TLS_FTPHandler
    from pyftpdlib.servers import FTPServer
    au = DummyAuthorizer(); au.add_user("bob", "pw", root, perm="elradfmwMT")
    if mode == "ftp":
        h = FTPHandler
    else:
        d = tempfile.mkdtemp(); cert = os.environ.get("FTP_TEST_CERT") or os.path.join(d, "c.pem")
        if not os.environ.get("FTP_TEST_CERT"): subprocess.check_call(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", cert, "-out", cert,
                               "-days", "2", "-subj", "/CN=127.0.0.1"], stderr=subprocess.DEVNULL)
        h = TLS_FTPHandler; h.certfile = cert; h.tls_control_required = True; h.tls_data_required = True
    h.authorizer = au; h.passive_ports = range(port + 1, port + 40)
    srv = FTPServer(("127.0.0.1", port), h); print("ready", flush=True); srv.serve_forever()
