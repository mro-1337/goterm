package main

import (
	"bufio"
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func freePort(t *testing.T) int {
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port
}

// startFileServer runs testdata/fileserver.py (needs python3 with
// pyftpdlib, paramiko and openssl; the test is skipped otherwise).
func startFileServer(t *testing.T, mode string) (port int, root string) {
	if _, err := exec.LookPath("python3"); err != nil {
		t.Skip("python3 not available")
	}
	if exec.Command("python3", "-c", "import pyftpdlib, paramiko, OpenSSL").Run() != nil {
		t.Skip("pyftpdlib/paramiko not installed")
	}
	root = t.TempDir()
	port = freePort(t)
	cmd := exec.Command("python3", "testdata/fileserver.py", mode, fmt.Sprint(port), root)
	out, _ := cmd.StdoutPipe()
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { cmd.Process.Kill(); cmd.Wait() })
	buf := make([]byte, 16)
	out.Read(buf)
	time.Sleep(200 * time.Millisecond)
	return
}

func exerciseFS(t *testing.T, fs FileSystem, root string) {
	big := make([]byte, 3*1024*1024+123)
	rand.Read(big)
	small := []byte("hello\r\nworld\n")
	wd, err := fs.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	put := func(name string, data []byte) {
		w, err := fs.Create(fs.Join(wd, name))
		if err != nil {
			t.Fatalf("create %s: %v", name, err)
		}
		if _, err := w.Write(data); err != nil {
			t.Fatalf("write %s: %v", name, err)
		}
		if err := w.Close(); err != nil {
			t.Fatalf("close %s: %v", name, err)
		}
	}
	get := func(name string) []byte {
		r, size, err := fs.Open(fs.Join(wd, name))
		if err != nil {
			t.Fatalf("open %s: %v", name, err)
		}
		b, err := io.ReadAll(r)
		if err != nil {
			t.Fatalf("read %s: %v", name, err)
		}
		if err := r.Close(); err != nil {
			t.Fatalf("close reader: %v", err)
		}
		if size >= 0 && size != int64(len(b)) {
			t.Fatalf("%s: size %d, read %d", name, size, len(b))
		}
		return b
	}
	put("small.txt", small)
	put("big.bin", big)
	if b, _ := os.ReadFile(filepath.Join(root, "big.bin")); !bytes.Equal(b, big) {
		t.Fatalf("server copy of big.bin differs (%d bytes)", len(b))
	}
	if !bytes.Equal(get("small.txt"), small) || !bytes.Equal(get("big.bin"), big) {
		t.Fatal("downloaded data differs")
	}
	// stop a download early, then keep using the connection
	r, _, err := fs.Open(fs.Join(wd, "big.bin"))
	if err != nil {
		t.Fatal(err)
	}
	r.Read(make([]byte, 1000))
	r.Close()
	if !bytes.Equal(get("small.txt"), small) {
		t.Fatal("connection unusable after early close")
	}
	if err := fs.Mkdir(fs.Join(wd, "sub")); err != nil {
		t.Fatalf("mkdir: %v", err)
	}
	if err := fs.Rename(fs.Join(wd, "small.txt"), fs.Join(wd, "sub/moved.txt")); err != nil {
		t.Fatalf("rename: %v", err)
	}
	l, err := fs.List(wd)
	if err != nil {
		t.Fatal(err)
	}
	var sawDir, sawBig bool
	for _, e := range l {
		if e.Name == "sub" && e.Dir {
			sawDir = true
		}
		if e.Name == "big.bin" && !e.Dir && e.Size == int64(len(big)) {
			sawBig = true
		}
	}
	if !sawDir || !sawBig {
		t.Fatalf("listing wrong: %+v", l)
	}
	l, _ = fs.List(fs.Join(wd, "sub"))
	if len(l) != 1 || l[0].Name != "moved.txt" {
		t.Fatalf("sub listing: %+v", l)
	}
	if err := fs.Remove(fs.Join(wd, "sub"), true); err == nil {
		t.Fatal("removing a non-empty folder should fail")
	}
	if err := fs.Remove(fs.Join(wd, "sub/moved.txt"), false); err != nil {
		t.Fatal(err)
	}
	if err := fs.Remove(fs.Join(wd, "sub"), true); err != nil {
		t.Fatal(err)
	}
	if _, _, err := fs.Open(fs.Join(wd, "nope")); err == nil {
		t.Fatal("opening a missing file should fail")
	}

	// the commander's copy engine: local folder tree -> remote and back
	src := t.TempDir()
	os.MkdirAll(filepath.Join(src, "tree/a/b"), 0o755)
	os.WriteFile(filepath.Join(src, "tree/x.txt"), []byte("x"), 0o644)
	os.WriteFile(filepath.Join(src, "tree/a/b/y.bin"), big[:200000], 0o644)
	c := &Commander{}
	c.name.Store("")
	o := &op{c}
	e := FileInfo{Name: "tree", Dir: true}
	o.scan(LocalFS{}, src, []FileInfo{e})
	if c.total.Load() != 200001 || c.files.Load() != 2 {
		t.Fatalf("scan: %d bytes %d files", c.total.Load(), c.files.Load())
	}
	if err := o.copyItem(LocalFS{}, filepath.Join(src, "tree"), e, fs, fs.Join(wd, "tree"), true); err != nil {
		t.Fatalf("upload tree: %v", err)
	}
	if c.done.Load() != 200001 {
		t.Fatalf("progress %d", c.done.Load())
	}
	back := t.TempDir()
	if err := o.copyItem(fs, fs.Join(wd, "tree"), e, LocalFS{}, filepath.Join(back, "tree"), true); err != nil {
		t.Fatalf("download tree: %v", err)
	}
	if b, _ := os.ReadFile(filepath.Join(back, "tree/a/b/y.bin")); !bytes.Equal(b, big[:200000]) {
		t.Fatal("tree round trip differs")
	}
	if err := o.remove(fs, fs.Join(wd, "tree"), e); err != nil {
		t.Fatalf("recursive delete: %v", err)
	}
	if err := fs.Remove(fs.Join(wd, "big.bin"), false); err != nil {
		t.Fatal(err)
	}
	if ents, _ := os.ReadDir(root); len(ents) != 0 {
		t.Fatalf("server not empty: %v", ents)
	}
}

func TestFTP(t *testing.T) {
	port, root := startFileServer(t, "ftp")
	fs, err := DialFTP("127.0.0.1", port, "ftp", "bob", "pw", 5*time.Second, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer fs.Close()
	exerciseFS(t, fs, root)
}

func TestFTPBadPassword(t *testing.T) {
	port, _ := startFileServer(t, "ftp")
	if _, err := DialFTP("127.0.0.1", port, "ftp", "bob", "wrong", 5*time.Second, nil); err == nil {
		t.Fatal("bad password accepted")
	}
}

func TestFTPES(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	port, root := startFileServer(t, "ftpes")
	fs, err := DialFTP("127.0.0.1", port, "ftpes", "bob", "pw", 5*time.Second, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer fs.Close()
	if !fs.useTLS {
		t.Fatal("not using TLS")
	}
	exerciseFS(t, fs, root)
	// the certificate was remembered: a second connection works too
	fs2, err := DialFTP("127.0.0.1", port, "ftpes", "bob", "pw", 5*time.Second, nil)
	if err != nil {
		t.Fatal(err)
	}
	fs2.Close()
}

func TestSFTP(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	port, root := startFileServer(t, "sftp")
	fs, err := DialSFTP(fmt.Sprintf("127.0.0.1:%d", port), "bob", "pw", 5*time.Second, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer fs.Close()
	exerciseFS(t, fs, root)
}

func TestParseList(t *testing.T) {
	cases := []struct {
		line string
		name string
		dir  bool
		size int64
	}{
		{"-rw-r--r--   1 ftp      ftp          1234 Jan 05 12:30 file one.txt", "file one.txt", false, 1234},
		{"drwxr-xr-x   2 user group 4096 Dec 25  2019 docs", "docs", true, 4096},
		{"lrwxrwxrwx 1 root root 7 Mar 3 10:00 link -> target", "link", false, 7},
		{"-rw-r--r-- 1 owner 99 Jan 5 12:30 nogroup.txt", "nogroup.txt", false, 99},
		{"01-23-24  09:15PM       <DIR>          Archive", "Archive", true, 0},
		{"11-02-19  03:05AM                 5678 data file.dat", "data file.dat", false, 5678},
	}
	for _, c := range cases {
		fi, ok := parseList(c.line)
		if !ok || fi.Name != c.name || fi.Dir != c.dir || fi.Size != c.size {
			t.Errorf("%q -> %+v ok=%v", c.line, fi, ok)
		}
	}
	fi, ok := parseMLSD("type=file;size=42;modify=20240102030405; my file.txt")
	if !ok || fi.Name != "my file.txt" || fi.Size != 42 || fi.Mod.Year() != 2024 {
		t.Errorf("mlsd: %+v", fi)
	}
	if _, ok := parseMLSD("type=cdir;modify=20240102030405; ."); ok {
		t.Error("cdir should be skipped")
	}
}

func TestEntryFromFTPURL(t *testing.T) {
	cfg := &Config{}
	e := entryFromTarget(cfg, "ftps://ann:s3cret@files.example.com/pub/in")
	if e.Conn != "ftps" || e.Host != "files.example.com" || e.Port != 990 || e.User != "ann" || e.Password != "s3cret" || e.RemoteDir != "/pub/in" {
		t.Fatalf("%+v", e)
	}
	e = entryFromTarget(cfg, "sftp://bob@host:2222")
	if e.Conn != "sftp" || e.Port != 2222 || e.User != "bob" {
		t.Fatalf("%+v", e)
	}
}

// tlsProxy terminates TLS on a new port and forwards the plaintext to
// backend, which imitates an implicit-TLS FTPS control connection.
func tlsProxy(t *testing.T, backend int, cert tls.Certificate) int {
	l, err := tls.Listen("tcp", "127.0.0.1:0", &tls.Config{Certificates: []tls.Certificate{cert}})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { l.Close() })
	go func() {
		for {
			c, err := l.Accept()
			if err != nil {
				return
			}
			go func() {
				b, err := net.Dial("tcp", fmt.Sprintf("127.0.0.1:%d", backend))
				if err != nil {
					c.Close()
					return
				}
				// upgrade the backend leg with AUTH TLS so the client sees an
				// implicit-TLS server
				br := bufio.NewReader(b)
				greet, _ := br.ReadString('\n')
				fmt.Fprintf(b, "AUTH TLS\r\n")
				if r, _ := br.ReadString('\n'); !strings.HasPrefix(r, "234") {
					c.Close()
					return
				}
				tb := tls.Client(b, &tls.Config{InsecureSkipVerify: true})
				if tb.Handshake() != nil {
					c.Close()
					return
				}
				io.WriteString(c, greet)
				go func() { io.Copy(tb, c); tb.Close() }()
				io.Copy(c, tb)
				c.Close()
			}()
		}
	}()
	return l.Addr().(*net.TCPAddr).Port
}

func selfSigned() (tls.Certificate, error) {
	k, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tpl := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "127.0.0.1"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour),
		IPAddresses: []net.IP{net.ParseIP("127.0.0.1")}}
	der, err := x509.CreateCertificate(rand.Reader, tpl, tpl, &k.PublicKey, k)
	return tls.Certificate{Certificate: [][]byte{der}, PrivateKey: k}, err
}

func TestFTPSImplicit(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	cert, err := selfSigned()
	if err != nil {
		t.Fatal(err)
	}
	pemPath := filepath.Join(t.TempDir(), "cert.pem")
	kb, _ := x509.MarshalPKCS8PrivateKey(cert.PrivateKey)
	os.WriteFile(pemPath, append(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: cert.Certificate[0]}),
		pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: kb})...), 0o600)
	t.Setenv("FTP_TEST_CERT", pemPath)
	port, root := startFileServer(t, "ftps")
	fs, err := DialFTP("127.0.0.1", tlsProxy(t, port, cert), "ftps", "bob", "pw", 5*time.Second, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer fs.Close()
	exerciseFS(t, fs, root)
}
