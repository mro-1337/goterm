package frame

import (
	"goterm/third_party/jxl/entropy"
	"goterm/third_party/jxl/jxlio"
	"goterm/third_party/jxl/util"
)

type Patch struct {
	Width         int32
	Height        int32
	Bounds        util.Rectangle
	Ref           int32
	Origin        util.Point
	Positions     []util.Point
	BlendingInfos [][]BlendingInfo
}

func NewPatchWithStreamAndReader(stream entropy.EntropyStreamer, reader jxlio.BitReader, extraChannelCount int, alphaChannelCount int) (Patch, error) {

	return Patch{}, nil
}
