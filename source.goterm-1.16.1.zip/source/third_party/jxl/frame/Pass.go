package frame

import (
	"goterm/third_party/jxl/entropy"
	"goterm/third_party/jxl/jxlio"
	"goterm/third_party/jxl/util"
)

type Pass struct {
	replacedChannels []*ModularChannel
	hfPass           *HFPass
	minShift         uint32
	maxShift         uint32
}

type NewHFPassWithReaderFunc func(reader jxlio.BitReader, frame Framer, passIndex uint32,
	readClusterMapFunc entropy.ReadClusterMapFunc,
	newEntropyStreamWithReader entropy.EntropyStreamWithReaderAndNumDistsFunc,
	readPermutation ReadPermutationFunc) (*HFPass, error)

func NewPassWithReader(reader jxlio.BitReader, frame Framer, passIndex uint32, prevMinShift uint32, hfPassFunc NewHFPassWithReaderFunc) (Pass, error) {
	p := Pass{}

	if passIndex > 0 {
		p.maxShift = prevMinShift
	} else {
		p.maxShift = 3
	}

	n := -1
	passes := frame.getFrameHeader().passes
	for i := 0; i < len(passes.lastPass); i++ {
		if passes.lastPass[i] == passIndex {
			n = i
			break
		}
	}

	if n >= 0 {
		p.minShift = uint32(util.CeilLog1p(int64(passes.downSample[n] - 1)))
	} else {
		p.minShift = p.maxShift
	}

	stream := frame.getLFGlobal().globalModular
	p.replacedChannels = make([]*ModularChannel, len(stream.getChannels()))
	for i := 0; i < len(p.replacedChannels); i++ {
		ch := stream.getChannels()[i]
		if !ch.decoded {
			m := uint32(min(ch.hshift, ch.vshift))
			if p.minShift <= m && m < p.maxShift {
				p.replacedChannels[i] = NewModularChannelFromChannel(*ch)
			}
		}
	}
	var err error
	if frame.getFrameHeader().Encoding == VARDCT {
		p.hfPass, err = hfPassFunc(reader, frame, passIndex, entropy.ReadClusterMap, entropy.NewEntropyStreamWithReaderAndNumDists, readPermutation)
		if err != nil {
			return Pass{}, err
		}
	} else {
		p.hfPass = nil
	}

	return p, nil

}
