// Package log is a no-op stand-in for logrus, so the vendored JPEG XL
// decoder needs no third-party modules. Messages are discarded.
package log

type Level uint32

const (
	ErrorLevel Level = 2
	DebugLevel Level = 5
)

func GetLevel() Level               { return ErrorLevel }
func Errorf(string, ...interface{}) {}
func Debugf(string, ...interface{}) {}
func Infof(string, ...interface{})  {}
func Warnf(string, ...interface{})  {}
func Errorln(...interface{})        {}
func Debugln(...interface{})        {}
