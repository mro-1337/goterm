package bundle

import (
	"errors"

	"goterm/third_party/jxl/jxlio"
)

type AnimationHeader struct {
	HaveTimeCodes bool
}

func NewAnimationHeader(reader jxlio.BitReader) (*AnimationHeader, error) {
	return nil, errors.New("Animation not implemented")
}
