package main

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func waitCmd(t *testing.T, a *App, what string, cond func() bool) {
	t.Helper()
	for i := 0; i < 200; i++ {
		a.mu.Lock()
		ok := cond()
		a.mu.Unlock()
		if ok {
			return
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatal("timed out waiting for " + what)
}

// Drives the two-pane screen with keys, as a user would.
func TestCommanderUI(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	t.Setenv("HOME", t.TempDir())
	port, root := startFileServer(t, "ftp")
	os.WriteFile(filepath.Join(root, "remote.txt"), []byte("from the server"), 0o644)
	os.Mkdir(filepath.Join(root, "pub"), 0o755)

	cfg := newDefaultConfig()
	cfg.DownDir = t.TempDir()
	os.WriteFile(filepath.Join(cfg.DownDir, "local.txt"), []byte("from this machine"), 0o644)
	a := NewApp(cfg)
	a.mu.Lock()
	a.connect(DialEntry{Name: "t", Host: "127.0.0.1", Port: port, Conn: "ftp", User: "bob", Password: "pw"}, -1)
	a.mu.Unlock()
	var c *Commander
	waitCmd(t, a, "commander", func() bool {
		if len(a.modals) > 0 {
			c, _ = a.modals[len(a.modals)-1].(*Commander)
		}
		return c != nil && len(c.p[0].ents) > 0 && len(c.p[1].ents) > 0
	})
	key := func(ev KeyEvent) { a.mu.Lock(); a.modals[len(a.modals)-1].Key(a, ev); a.mu.Unlock() }
	idle := func() { waitCmd(t, a, "idle", func() bool { return !c.busy && c.p[0].gen > 0 }); time.Sleep(150 * time.Millisecond) }
	if os.Getenv("SHOTS") != "" {
		shotPNG(t, a, "/tmp/commander.png")
	}
	// right pane: select remote.txt, copy to the left pane
	a.mu.Lock()
	r := c.p[1]
	for i, e := range r.ents {
		if e.Name == "remote.txt" {
			r.sel = i
		}
	}
	a.mu.Unlock()
	key(KeyEvent{Key: KeyF5})
	key(KeyEvent{Ch: 'y'})
	idle()
	if b, err := os.ReadFile(filepath.Join(cfg.DownDir, "remote.txt")); err != nil || string(b) != "from the server" {
		t.Fatalf("download failed: %v %q", err, b)
	}
	// left pane: copy local.txt up
	key(KeyEvent{Key: KeyTab})
	a.mu.Lock()
	l := c.p[0]
	for i, e := range l.ents {
		if e.Name == "local.txt" {
			l.sel = i
		}
	}
	a.mu.Unlock()
	key(KeyEvent{Key: KeyF5})
	key(KeyEvent{Ch: 'y'})
	idle()
	if b, err := os.ReadFile(filepath.Join(root, "local.txt")); err != nil || string(b) != "from this machine" {
		t.Fatalf("upload failed: %v %q", err, b)
	}
	// mkdir on the remote side, delete the uploaded file
	key(KeyEvent{Key: KeyTab})
	key(KeyEvent{Key: KeyF7})
	for _, ch := range "newdir" {
		key(KeyEvent{Ch: ch})
	}
	key(KeyEvent{Key: KeyEnter})
	idle()
	if st, err := os.Stat(filepath.Join(root, "newdir")); err != nil || !st.IsDir() {
		t.Fatal("mkdir failed")
	}
	a.mu.Lock()
	for i, e := range c.p[1].ents {
		if e.Name == "local.txt" {
			c.p[1].sel = i
		}
	}
	a.mu.Unlock()
	key(KeyEvent{Key: KeyF8})
	key(KeyEvent{Ch: 'y'})
	idle()
	if _, err := os.Stat(filepath.Join(root, "local.txt")); err == nil {
		t.Fatal("delete failed")
	}
	// enter a folder and come back up
	a.mu.Lock()
	for i, e := range c.p[1].ents {
		if e.Name == "pub" {
			c.p[1].sel = i
		}
	}
	a.mu.Unlock()
	key(KeyEvent{Key: KeyEnter})
	idle()
	a.mu.Lock()
	inPub := c.p[1].dir
	a.mu.Unlock()
	if filepath.Base(inPub) != "pub" {
		t.Fatalf("not in pub: %q", inPub)
	}
	key(KeyEvent{Key: KeyBS})
	idle()
	key(KeyEvent{Key: KeyF10})
	a.mu.Lock()
	defer a.mu.Unlock()
	for _, m := range a.modals {
		if m == Modal(c) {
			t.Fatal("commander still open")
		}
	}
}
