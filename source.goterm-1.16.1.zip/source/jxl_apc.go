package main

import (
	"fmt"
	"image"
	"image/color"
	"strconv"
	"strings"
)

// SyncTERM graphics APCs that draw an image onto the pixel layer:
//
//	SyncTERM:C;S;<file>;<base64>                  store an image (kept in memory here)
//	SyncTERM:C;DrawJXL;<opts>;<file>              draw a stored JPEG XL
//	SyncTERM:C;DrawJXLBlob;<opts>;<base64>        draw an inline JPEG XL
//	SyncTERM:C;DrawPPM / DrawPPMBlob              the same for PPM
//
// <opts> are SX= SY= SW= SH= (source rectangle), DX= DY= (destination in
// canvas pixels), ZX= ZY= (integer zoom) and the flags FX FY (mirror).
// Mask options and the copy buffers are not implemented.

// cterm revision reported in the DA1 reply. 1.332 is the revision that has
// the Draw*Blob verbs and ZX/ZY zoom, which is what the Synchronet doors
// key their image path on.
const ctermMajor, ctermMinor = 1, 332

const maxStoredImages = 8

// storeImage keeps an uploaded image file in memory, under its name.
func (p *Parser) storeImage(name string, data []byte) {
	if p.imgs == nil {
		p.imgs = map[string][]byte{}
	}
	if len(p.imgs) >= maxStoredImages {
		for k := range p.imgs { // drop an arbitrary old one
			delete(p.imgs, k)
			break
		}
	}
	p.imgs[name] = data
}

func isImageName(n string) bool {
	n = strings.ToLower(n)
	return strings.HasSuffix(n, ".jxl") || strings.HasSuffix(n, ".ppm")
}

type drawOpts struct {
	sx, sy, sw, sh int
	dx, dy         int
	zx, zy         int
	fx, fy         bool
}

func parseDrawOpts(toks []string) drawOpts {
	o := drawOpts{zx: 1, zy: 1, sw: -1, sh: -1}
	for _, t := range toks {
		k, v, hasV := strings.Cut(t, "=")
		n, _ := strconv.Atoi(v)
		switch strings.ToUpper(k) {
		case "SX":
			o.sx = n
		case "SY":
			o.sy = n
		case "SW":
			o.sw = n
		case "SH":
			o.sh = n
		case "DX":
			o.dx = n
		case "DY":
			o.dy = n
		case "ZX":
			o.zx = n
		case "ZY":
			o.zy = n
		case "FX":
			o.fx = !hasV || n != 0
		case "FY":
			o.fy = !hasV || n != 0
		}
	}
	if o.zx < 1 {
		o.zx = 1
	}
	if o.zy < 1 {
		o.zy = 1
	}
	return o
}

// drawImageAPC handles "C;Draw<fmt>[Blob];opts;file-or-data". verb is the
// part after "C;" up to the first ';', rest is the remainder.
func (p *Parser) drawImageAPC(verb, rest string) {
	toks := strings.Split(rest, ";")
	arg := toks[len(toks)-1]
	opts := parseDrawOpts(toks[:len(toks)-1])
	blob := strings.HasSuffix(verb, "Blob")
	var data []byte
	if blob {
		var ok bool
		if data, ok = decodeB64(arg); !ok {
			return
		}
	} else {
		var ok bool
		if data, ok = p.imgs[arg]; !ok {
			return
		}
	}
	jxl := strings.HasPrefix(verb, "DrawJXL")
	decode := func() image.Image {
		var img image.Image
		var err error
		if jxl {
			img, err = decodeJXL(data)
		} else {
			img, err = decodePPM(data)
		}
		if err != nil {
			return nil
		}
		return img
	}
	// Decoding a JPEG XL frame takes tens of milliseconds; do it with the
	// application lock released so the window stays responsive.
	var img image.Image
	if p.Yield != nil {
		p.Yield(func() { img = decode() })
	} else {
		img = decode()
	}
	if img != nil {
		p.S.DrawPixels(img, opts)
	}
}

// DrawPixels blits img (with source rectangle, flips and zoom applied) onto
// the pixel layer at the destination in opts, clipping to the screen.
func (s *Screen) DrawPixels(img image.Image, o drawOpts) {
	b := img.Bounds()
	iw, ih := b.Dx(), b.Dy()
	if o.sx < 0 {
		o.sx = 0
	}
	if o.sy < 0 {
		o.sy = 0
	}
	if o.sw < 0 || o.sx+o.sw > iw {
		o.sw = iw - o.sx
	}
	if o.sh < 0 || o.sy+o.sh > ih {
		o.sh = ih - o.sy
	}
	if o.sw <= 0 || o.sh <= 0 {
		return
	}
	s.ensureGfx()
	stride := s.gfxStride()
	maxW, maxH := s.Cols*s.CW, s.Rows*s.CH
	var pix func(x, y int) uint32
	switch m := img.(type) {
	case *image.RGBA:
		pix = func(x, y int) uint32 {
			i := (y-b.Min.Y)*m.Stride + (x-b.Min.X)*4
			return 0xFF000000 | uint32(m.Pix[i])<<16 | uint32(m.Pix[i+1])<<8 | uint32(m.Pix[i+2])
		}
	case *image.NRGBA:
		pix = func(x, y int) uint32 {
			i := (y-b.Min.Y)*m.Stride + (x-b.Min.X)*4
			return 0xFF000000 | uint32(m.Pix[i])<<16 | uint32(m.Pix[i+1])<<8 | uint32(m.Pix[i+2])
		}
	default:
		pix = func(x, y int) uint32 {
			c := color.NRGBAModel.Convert(img.At(x, y)).(color.NRGBA)
			return 0xFF000000 | uint32(c.R)<<16 | uint32(c.G)<<8 | uint32(c.B)
		}
	}
	outW, outH := o.sw*o.zx, o.sh*o.zy
	for oy := 0; oy < outH; oy++ {
		dy := o.dy + oy
		if dy < 0 {
			continue
		}
		if dy >= maxH {
			break
		}
		sy := oy / o.zy
		if o.fy {
			sy = o.sh - 1 - sy
		}
		sy += o.sy + b.Min.Y
		row := s.gfx[dy*stride : (dy+1)*stride]
		for ox := 0; ox < outW; ox++ {
			dx := o.dx + ox
			if dx < 0 {
				continue
			}
			if dx >= maxW {
				break
			}
			sx := ox / o.zx
			if o.fx {
				sx = o.sw - 1 - sx
			}
			row[dx] = pix(sx+o.sx+b.Min.X, sy)
		}
	}
	s.Dirty = true
}

// decodePPM reads a binary (P6) or text (P3) PPM.
func decodePPM(b []byte) (image.Image, error) {
	pos := 0
	tok := func() string {
		for pos < len(b) {
			if b[pos] == '#' {
				for pos < len(b) && b[pos] != '\n' {
					pos++
				}
			} else if b[pos] == ' ' || b[pos] == '\t' || b[pos] == '\r' || b[pos] == '\n' {
				pos++
			} else {
				break
			}
		}
		st := pos
		for pos < len(b) && !(b[pos] == ' ' || b[pos] == '\t' || b[pos] == '\r' || b[pos] == '\n') {
			pos++
		}
		return string(b[st:pos])
	}
	magic := tok()
	if magic != "P6" && magic != "P3" {
		return nil, fmt.Errorf("ppm: bad magic")
	}
	w, _ := strconv.Atoi(tok())
	h, _ := strconv.Atoi(tok())
	mx, _ := strconv.Atoi(tok())
	if w <= 0 || h <= 0 || w*h > 16<<20 || mx <= 0 || mx > 255 {
		return nil, fmt.Errorf("ppm: bad header")
	}
	img := image.NewNRGBA(image.Rect(0, 0, w, h))
	scale := func(v int) uint8 { return uint8(v * 255 / mx) }
	if magic == "P6" {
		pos++ // one whitespace byte after the header
		if len(b)-pos < w*h*3 {
			return nil, fmt.Errorf("ppm: truncated")
		}
		for i := 0; i < w*h; i++ {
			img.Pix[i*4] = scale(int(b[pos]))
			img.Pix[i*4+1] = scale(int(b[pos+1]))
			img.Pix[i*4+2] = scale(int(b[pos+2]))
			img.Pix[i*4+3] = 255
			pos += 3
		}
		return img, nil
	}
	for i := 0; i < w*h; i++ {
		for c := 0; c < 3; c++ {
			v, err := strconv.Atoi(tok())
			if err != nil {
				return nil, fmt.Errorf("ppm: truncated")
			}
			img.Pix[i*4+c] = scale(v)
		}
		img.Pix[i*4+3] = 255
	}
	return img, nil
}
