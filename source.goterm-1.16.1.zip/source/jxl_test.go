package main

import (
	"bytes"
	"encoding/base64"
	"image"
	"image/png"
	"math"
	"os"
	"testing"
	"time"
)

func psnr(a, b image.Image) float64 {
	r := a.Bounds()
	var se float64
	n := 0
	for y := r.Min.Y; y < r.Max.Y; y++ {
		for x := r.Min.X; x < r.Max.X; x++ {
			ar, ag, ab, _ := a.At(x, y).RGBA()
			br, bg, bb, _ := b.At(x, y).RGBA()
			for _, d := range []float64{float64(ar>>8) - float64(br>>8), float64(ag>>8) - float64(bg>>8), float64(ab>>8) - float64(bb>>8)} {
				se += d * d
				n++
			}
		}
	}
	if se == 0 {
		return 99
	}
	return 10 * math.Log10(255*255/(se/float64(n)))
}

func TestJXLDrawAPC(t *testing.T) {
	data, err := os.ReadFile("testdata/jxl_doom_d2.jxl")
	if err != nil {
		t.Fatal(err)
	}
	want, err := decodeJXL(data)
	if err != nil {
		t.Fatal(err)
	}
	b64 := base64.StdEncoding.EncodeToString(data)
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	var replies []string
	p.Reply = func(b []byte) { replies = append(replies, string(b)) }

	p.Feed([]byte("\x1b_SyncTERM:Q;JXL\x1b\\\x1b[c"))
	if len(replies) != 2 || replies[0] != "\x1b[=1;1-n" || replies[1] != "\x1b[=67;84;101;114;109;1;332c" {
		t.Fatalf("replies %q", replies)
	}
	px := func(x, y int) uint32 { s.ensureGfx(); return s.gfx[y*s.gfxStride()+x] }
	rgb := func(x, y int) uint32 {
		r, g, b, _ := want.At(x, y).RGBA()
		return 0xFF000000 | (r>>8)<<16 | (g>>8)<<8 | b>>8
	}

	// cached: store, then draw with an offset
	p.Feed([]byte("\x1b_SyncTERM:C;S;syncdoom_1.jxl;" + b64 + "\x1b\\"))
	p.Feed([]byte("\x1b_SyncTERM:C;DrawJXL;DX=0;DY=0;syncdoom_1.jxl\x1b\\"))
	for _, pt := range [][2]int{{0, 0}, {100, 50}, {639, 383}} {
		if px(pt[0], pt[1]) != rgb(pt[0], pt[1]) {
			t.Errorf("cached draw: pixel %v = %08x want %08x", pt, px(pt[0], pt[1]), rgb(pt[0], pt[1]))
		}
	}
	// inline blob, zoom 2 of a source rectangle, flipped
	s2 := NewScreen(80, 25, 8, 16)
	p2 := NewParser(s2)
	p2.Feed([]byte("\x1b_SyncTERM:C;DrawJXLBlob;DX=10;DY=20;SX=4;SY=6;SW=8;SH=8;ZX=2;ZY=2;FX;" + b64 + "\x1b\\"))
	s2.ensureGfx()
	got := func(x, y int) uint32 { return s2.gfx[y*s2.gfxStride()+x] }
	// output (10,20) is the mirrored right edge of the source rect: source (11,6)
	if got(10, 20) != rgb(11, 6) || got(11, 21) != rgb(11, 6) {
		t.Errorf("zoom/flip: %08x %08x want %08x", got(10, 20), got(11, 21), rgb(11, 6))
	}
	if got(10+16, 20) != 0 || got(9, 20) != 0 {
		t.Error("drew outside the destination rectangle")
	}
	// the store did not go to the audio cache
	if len(p.imgs) != 1 {
		t.Errorf("stored images: %d", len(p.imgs))
	}
}

func TestJXLDecode(t *testing.T) {
	f, _ := os.Open("testdata/jxl_frame.png")
	ref, err := png.Decode(f)
	f.Close()
	if err != nil {
		t.Fatal(err)
	}
	for _, c := range []struct {
		file string
		min  float64
	}{{"testdata/jxl_frame_d2.jxl", 23}, {"testdata/jxl_frame_lossless.jxl", 50}} {
		b, err := os.ReadFile(c.file)
		if err != nil {
			t.Fatal(err)
		}
		t0 := time.Now()
		img, err := decodeJXL(b)
		el := time.Since(t0)
		if err != nil {
			t.Fatalf("%s: %v", c.file, err)
		}
		if img.Bounds().Dx() != 640 || img.Bounds().Dy() != 384 {
			t.Fatalf("%s: size %v", c.file, img.Bounds())
		}
		p := psnr(ref, img)
		t.Logf("%s: %d bytes, %v, PSNR %.1f dB", c.file, len(b), el, p)
		if p < c.min {
			t.Errorf("%s: PSNR %.1f below %.1f", c.file, p, c.min)
		}
	}
	_ = bytes.NewReader
}

// The reference PNG is libjxl's own decode of the same file.
func TestJXLvsLibjxl(t *testing.T) {
	ref, err := os.Open("testdata/jxl_frame_d2_ref.png")
	if err != nil {
		t.Fatal(err)
	}
	r, err := png.Decode(ref)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile("testdata/jxl_frame_d2.jxl")
	img, err := decodeJXL(b)
	if err != nil {
		t.Fatal(err)
	}
	if p := psnr(r, img); p < 45 {
		t.Errorf("differs from libjxl output: %.1f dB", p)
	}
}

func TestJXLCorrupt(t *testing.T) {
	data, _ := os.ReadFile("testdata/jxl_doom_d2.jxl")
	for _, n := range []int{0, 2, 10, 100, len(data) / 2, len(data) - 1} {
		decodeJXL(data[:n]) // must not panic or hang
	}
	bad := append([]byte(nil), data...)
	for i := 20; i < len(bad); i += 97 {
		bad[i] ^= 0x5A
	}
	decodeJXL(bad)
}
