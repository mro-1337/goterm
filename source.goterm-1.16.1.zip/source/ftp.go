package main

import (
	"bufio"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/textproto"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// FTP / FTPS client (RFC 959, 2228, 4217, 2428, 3659). Modes:
//
//	ftp    plain FTP
//	ftpes  explicit TLS (AUTH TLS on the normal port)
//	ftps   implicit TLS (TLS from the first byte, usually port 990)
//
// Certificates are checked against the system roots; a certificate that
// does not verify (common on FTPS servers) is remembered on first use and
// refused if it changes later, like SSH host keys.

type FTPFS struct {
	mu     sync.Mutex
	nc     net.Conn
	tp     *textproto.Conn
	host   string
	port   int
	tlsCfg *tls.Config
	useTLS bool
	mlsd   bool
	cwd    string
	label  string
}

func (f *FTPFS) Name() string { return f.label }

func knownCertsPath() string {
	d, err := os.UserConfigDir()
	if err != nil || d == "" {
		return ""
	}
	return filepath.Join(d, "GoTerm", "known_certs")
}

// ftpTLSConfig builds a TLS config that verifies normally, and otherwise
// trusts a certificate on first use.
func ftpTLSConfig(host string, port int) *tls.Config {
	key := net.JoinHostPort(host, strconv.Itoa(port))
	return &tls.Config{
		ServerName:         host,
		MinVersion:         tls.VersionTLS12,
		ClientSessionCache: tls.NewLRUClientSessionCache(16),
		InsecureSkipVerify: true,
		VerifyConnection: func(cs tls.ConnectionState) error {
			if len(cs.PeerCertificates) == 0 {
				return errors.New("no server certificate")
			}
			inter := x509.NewCertPool()
			for _, c := range cs.PeerCertificates[1:] {
				inter.AddCert(c)
			}
			if _, err := cs.PeerCertificates[0].Verify(x509.VerifyOptions{DNSName: host, Intermediates: inter}); err == nil {
				return nil
			}
			sum := sha256.Sum256(cs.PeerCertificates[0].Raw)
			fp := hex.EncodeToString(sum[:])
			path := knownCertsPath()
			if path == "" {
				return nil
			}
			os.MkdirAll(filepath.Dir(path), 0o700)
			if b, err := os.ReadFile(path); err == nil {
				for _, ln := range strings.Split(string(b), "\n") {
					if k, v, ok := strings.Cut(strings.TrimSpace(ln), " "); ok && k == key {
						if v == fp {
							return nil
						}
						return fmt.Errorf("CERTIFICATE CHANGED for %s - refusing to connect (edit %s if this is expected)", key, path)
					}
				}
			}
			f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
			if err != nil {
				return err
			}
			defer f.Close()
			_, err = fmt.Fprintf(f, "%s %s\n", key, fp)
			return err
		},
	}
}

// DialFTP connects and logs in. askPass is used when pass is empty and the
// server wants a password.
func DialFTP(host string, port int, mode, user, pass string, timeout time.Duration, askPass func() (string, error)) (*FTPFS, error) {
	f := &FTPFS{host: host, port: port, tlsCfg: ftpTLSConfig(host, port), cwd: "/"}
	f.label = map[string]string{"ftp": "FTP", "ftpes": "FTPS", "ftps": "FTPS"}[mode] + " " + host
	addr := net.JoinHostPort(host, strconv.Itoa(port))
	d := net.Dialer{Timeout: timeout}
	nc, err := d.Dial("tcp", addr)
	if err != nil {
		return nil, err
	}
	if mode == "ftps" {
		tc := tls.Client(nc, f.tlsCfg)
		nc.SetDeadline(time.Now().Add(timeout))
		if err := tc.Handshake(); err != nil {
			nc.Close()
			return nil, err
		}
		nc.SetDeadline(time.Time{})
		nc = tc
		f.useTLS = true
	}
	f.nc = nc
	f.tp = textproto.NewConn(nc)
	nc.SetDeadline(time.Now().Add(timeout))
	if _, _, err := f.tp.ReadResponse(2); err != nil {
		nc.Close()
		return nil, err
	}
	nc.SetDeadline(time.Time{})
	fail := func(err error) (*FTPFS, error) { nc.Close(); return nil, err }
	if mode == "ftpes" {
		if _, _, err := f.cmd(2, "AUTH TLS"); err != nil {
			return fail(fmt.Errorf("the server does not support TLS: %w", err))
		}
		tc := tls.Client(nc, f.tlsCfg)
		if err := tc.Handshake(); err != nil {
			return fail(err)
		}
		f.nc = tc
		f.tp = textproto.NewConn(tc)
		f.useTLS = true
	}
	if user == "" {
		user = "anonymous"
		if pass == "" {
			pass = "goterm@"
		}
	}
	code, _, err := f.cmd(0, "USER %s", user)
	if err != nil {
		return fail(err)
	}
	if code == 331 || code == 332 {
		if pass == "" && askPass != nil {
			if pass, err = askPass(); err != nil {
				return fail(err)
			}
		}
		if _, _, err := f.cmd(2, "PASS %s", pass); err != nil {
			return fail(err)
		}
	} else if code/100 != 2 {
		return fail(fmt.Errorf("login refused (%d)", code))
	}
	if f.useTLS {
		f.cmd(0, "PBSZ 0")
		f.cmd(0, "PROT P")
	}
	f.cmd(0, "TYPE I")
	f.cmd(0, "OPTS UTF8 ON")
	if _, msg, err := f.cmd(2, "FEAT"); err == nil && strings.Contains(strings.ToUpper(msg), "MLST") {
		f.mlsd = true
	}
	return f, nil
}

// cmd sends a command and reads the reply. want is the expected first
// digit (0 = accept anything and return the code). Callers hold f.mu or are
// single-threaded (login).
func (f *FTPFS) cmd(want int, format string, args ...any) (int, string, error) {
	if err := f.tp.PrintfLine(format, args...); err != nil {
		return 0, "", err
	}
	return f.readReply(want)
}

func (f *FTPFS) readReply(want int) (int, string, error) {
	f.nc.SetReadDeadline(time.Now().Add(60 * time.Second))
	defer f.nc.SetReadDeadline(time.Time{})
	if want == 0 {
		code, msg, err := f.tp.ReadResponse(0)
		var te *textproto.Error
		if errors.As(err, &te) {
			return te.Code, te.Msg, nil
		}
		return code, msg, err
	}
	code, msg, err := f.tp.ReadResponse(want)
	var te *textproto.Error
	if errors.As(err, &te) {
		return te.Code, te.Msg, fmt.Errorf("%d %s", te.Code, strings.TrimSpace(te.Msg))
	}
	return code, msg, err
}

var epsvRe = regexp.MustCompile(`\|\|\|(\d+)\|`)

// dataConn opens a passive-mode data connection (TLS when the control
// connection is protected).
func (f *FTPFS) dataConn() (net.Conn, error) {
	var port int
	if _, msg, err := f.cmd(2, "EPSV"); err == nil {
		if m := epsvRe.FindStringSubmatch(msg); m != nil {
			port, _ = strconv.Atoi(m[1])
		}
	}
	if port == 0 {
		_, msg, err := f.cmd(2, "PASV")
		if err != nil {
			return nil, err
		}
		i, j := strings.Index(msg, "("), strings.LastIndex(msg, ")")
		if i < 0 || j < i {
			return nil, fmt.Errorf("bad PASV reply: %s", msg)
		}
		p := strings.Split(msg[i+1:j], ",")
		if len(p) != 6 {
			return nil, fmt.Errorf("bad PASV reply: %s", msg)
		}
		hi, _ := strconv.Atoi(strings.TrimSpace(p[4]))
		lo, _ := strconv.Atoi(strings.TrimSpace(p[5]))
		port = hi<<8 | lo
	}
	// Always use the address we reached the server on (many servers behind
	// NAT report a private address in PASV).
	dc, err := net.DialTimeout("tcp", net.JoinHostPort(f.host, strconv.Itoa(port)), 15*time.Second)
	if err != nil {
		return nil, err
	}
	if f.useTLS {
		tc := tls.Client(dc, f.tlsCfg)
		dc.SetDeadline(time.Now().Add(15 * time.Second))
		if err := tc.Handshake(); err != nil {
			dc.Close()
			return nil, err
		}
		dc.SetDeadline(time.Time{})
		return tc, nil
	}
	return dc, nil
}

func (f *FTPFS) Getwd() (string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	_, msg, err := f.cmd(2, "PWD")
	if err != nil {
		return "/", err
	}
	if i := strings.Index(msg, "\""); i >= 0 {
		if j := strings.LastIndex(msg, "\""); j > i {
			f.cwd = strings.ReplaceAll(msg[i+1:j], "\"\"", "\"")
			return f.cwd, nil
		}
	}
	return "/", nil
}

func (f *FTPFS) chdir(dir string) error {
	if dir == f.cwd {
		return nil
	}
	if _, _, err := f.cmd(2, "CWD %s", dir); err != nil {
		return err
	}
	f.cwd = dir
	return nil
}

func (f *FTPFS) List(dir string) ([]FileInfo, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if err := f.chdir(dir); err != nil {
		return nil, err
	}
	verb := "LIST"
	if f.mlsd {
		verb = "MLSD"
	}
	dc, err := f.dataConn()
	if err != nil {
		return nil, err
	}
	if _, _, err := f.cmd(1, "%s", verb); err != nil {
		dc.Close()
		return nil, err
	}
	var out []FileInfo
	sc := bufio.NewScanner(dc)
	sc.Buffer(make([]byte, 64*1024), 1<<20)
	for sc.Scan() {
		var fi FileInfo
		var ok bool
		if f.mlsd {
			fi, ok = parseMLSD(sc.Text())
		} else {
			fi, ok = parseList(sc.Text())
		}
		if ok && fi.Name != "." && fi.Name != ".." {
			out = append(out, fi)
		}
	}
	dc.Close()
	if _, _, err := f.readReply(2); err != nil {
		return out, err
	}
	return out, nil
}

func parseMLSD(line string) (FileInfo, bool) {
	facts, name, ok := strings.Cut(line, " ")
	if !ok || name == "" {
		return FileInfo{}, false
	}
	fi := FileInfo{Name: name, Size: -1}
	for _, kv := range strings.Split(facts, ";") {
		k, v, ok := strings.Cut(kv, "=")
		if !ok {
			continue
		}
		switch strings.ToLower(k) {
		case "type":
			switch strings.ToLower(v) {
			case "dir":
				fi.Dir = true
			case "cdir", "pdir":
				return fi, false
			case "os.unix=symlink", "os.unix=slink":
				fi.Link = true
			}
		case "size":
			fi.Size, _ = strconv.ParseInt(v, 10, 64)
		case "modify":
			if len(v) >= 14 {
				fi.Mod, _ = time.Parse("20060102150405", v[:14])
			}
		}
	}
	if fi.Size < 0 {
		fi.Size = 0
	}
	return fi, true
}

var (
	unixListRe = regexp.MustCompile(`^([\-ldbcps])[rwxsStT\-]{9}[+@.]?\s+\d+\s+\S+\s+(?:\S+\s+)?(\d+)\s+(\w{3})\s+(\d{1,2})\s+(\d{1,2}:\d{2}|\d{4})\s+(.+)$`)
	dosListRe  = regexp.MustCompile(`^(\d{2})-(\d{2})-(\d{2,4})\s+(\d{1,2}):(\d{2})\s*([AP]M)?\s+(<DIR>|\d+)\s+(.+)$`)
)

func parseList(line string) (FileInfo, bool) {
	line = strings.TrimRight(line, "\r\n")
	if m := unixListRe.FindStringSubmatch(line); m != nil {
		fi := FileInfo{Name: m[6], Dir: m[1] == "d", Link: m[1] == "l"}
		fi.Size, _ = strconv.ParseInt(m[2], 10, 64)
		if fi.Link {
			if i := strings.Index(fi.Name, " -> "); i > 0 {
				fi.Name = fi.Name[:i]
			}
		}
		now := time.Now()
		if strings.Contains(m[5], ":") {
			t, err := time.Parse("Jan 2 15:04 2006", fmt.Sprintf("%s %s %s %d", m[3], m[4], m[5], now.Year()))
			if err == nil {
				if t.After(now.Add(48 * time.Hour)) {
					t = t.AddDate(-1, 0, 0)
				}
				fi.Mod = t
			}
		} else if t, err := time.Parse("Jan 2 2006", fmt.Sprintf("%s %s %s", m[3], m[4], m[5])); err == nil {
			fi.Mod = t
		}
		return fi, true
	}
	if m := dosListRe.FindStringSubmatch(line); m != nil {
		fi := FileInfo{Name: m[8], Dir: m[7] == "<DIR>"}
		if !fi.Dir {
			fi.Size, _ = strconv.ParseInt(m[7], 10, 64)
		}
		y, _ := strconv.Atoi(m[3])
		if y < 100 {
			y += 2000
			if y > time.Now().Year()+1 {
				y -= 100
			}
		}
		mo, _ := strconv.Atoi(m[1])
		d, _ := strconv.Atoi(m[2])
		h, _ := strconv.Atoi(m[4])
		mi, _ := strconv.Atoi(m[5])
		if m[6] == "PM" && h < 12 {
			h += 12
		}
		if m[6] == "AM" && h == 12 {
			h = 0
		}
		fi.Mod = time.Date(y, time.Month(mo), d, h, mi, 0, 0, time.UTC)
		return fi, true
	}
	return FileInfo{}, false
}

// ftpXfer is the data connection of a running RETR or STOR. It holds the
// control connection until Close reads the final reply.
type ftpXfer struct {
	f    *FTPFS
	dc   net.Conn
	read bool
	eof  bool
	err  error
}

func (x *ftpXfer) Read(p []byte) (int, error) {
	n, err := x.dc.Read(p)
	if err == io.EOF {
		x.eof = true
	} else if err != nil {
		x.err = err
	}
	return n, err
}

func (x *ftpXfer) Write(p []byte) (int, error) {
	n, err := x.dc.Write(p)
	if err != nil {
		x.err = err
	}
	return n, err
}

func (x *ftpXfer) Close() error {
	defer x.f.mu.Unlock()
	if !x.read {
		// Uploads: say "end of data" (TLS close_notify / TCP FIN) and wait
		// for the server to close its side, so it has certainly consumed
		// everything we sent before we tear the connection down.
		if tc, ok := x.dc.(*tls.Conn); ok {
			tc.CloseWrite()
		} else if tcp, ok := x.dc.(*net.TCPConn); ok {
			tcp.CloseWrite()
		}
		x.dc.SetReadDeadline(time.Now().Add(5 * time.Second))
		io.Copy(io.Discard, x.dc)
	}
	x.dc.Close()
	if x.read && !x.eof {
		// stopped early: the server answers 426/451 (and sometimes 226)
		if _, _, err := x.f.readReply(0); err != nil {
			x.f.nc.Close()
		}
		return nil
	}
	if _, _, err := x.f.readReply(2); err != nil {
		return err
	}
	return x.err
}

func (f *FTPFS) startXfer(verb, p string, read bool) (*ftpXfer, error) {
	f.mu.Lock()
	dc, err := f.dataConn()
	if err != nil {
		f.mu.Unlock()
		return nil, err
	}
	if _, _, err := f.cmd(1, "%s %s", verb, p); err != nil {
		dc.Close()
		f.mu.Unlock()
		return nil, err
	}
	return &ftpXfer{f: f, dc: dc, read: read}, nil
}

func (f *FTPFS) Open(p string) (io.ReadCloser, int64, error) {
	size := int64(-1)
	f.mu.Lock()
	if _, msg, err := f.cmd(2, "SIZE %s", p); err == nil {
		size, _ = strconv.ParseInt(strings.TrimSpace(msg), 10, 64)
	}
	f.mu.Unlock()
	x, err := f.startXfer("RETR", p, true)
	if err != nil {
		return nil, 0, err
	}
	return x, size, nil
}

func (f *FTPFS) Create(p string) (io.WriteCloser, error) {
	return f.startXfer("STOR", p, false)
}

func (f *FTPFS) simple(format string, args ...any) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	_, _, err := f.cmd(2, format, args...)
	return err
}

func (f *FTPFS) Mkdir(p string) error { return f.simple("MKD %s", p) }

func (f *FTPFS) Remove(p string, dir bool) error {
	if dir {
		return f.simple("RMD %s", p)
	}
	return f.simple("DELE %s", p)
}

func (f *FTPFS) Rename(a, b string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, _, err := f.cmd(3, "RNFR %s", a); err != nil {
		return err
	}
	_, _, err := f.cmd(2, "RNTO %s", b)
	return err
}

func (f *FTPFS) Join(dir, name string) string { return path.Join(dir, name) }
func (f *FTPFS) Parent(dir string) string     { return path.Dir(dir) }

func (f *FTPFS) Close() error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.tp.PrintfLine("QUIT")
	return f.nc.Close()
}
