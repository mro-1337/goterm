package main

import (
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// FileSystem is what the two-pane file manager works on: the local disk,
// an FTP/FTPS server or an SFTP server.
type FileSystem interface {
	Name() string
	Getwd() (string, error)
	List(dir string) ([]FileInfo, error)
	Open(path string) (io.ReadCloser, int64, error) // size is -1 if unknown
	Create(path string) (io.WriteCloser, error)
	Mkdir(path string) error
	Remove(path string, dir bool) error
	Rename(from, to string) error
	Join(dir, name string) string
	Parent(dir string) string
	Close() error
}

type FileInfo struct {
	Name string
	Size int64
	Dir  bool
	Link bool
	Mod  time.Time
}

func sortInfos(l []FileInfo, by string) {
	sort.SliceStable(l, func(i, j int) bool {
		if l[i].Dir != l[j].Dir {
			return l[i].Dir
		}
		switch by {
		case "size":
			if l[i].Size != l[j].Size {
				return l[i].Size > l[j].Size
			}
		case "time":
			if !l[i].Mod.Equal(l[j].Mod) {
				return l[i].Mod.After(l[j].Mod)
			}
		}
		return strings.ToLower(l[i].Name) < strings.ToLower(l[j].Name)
	})
}

// ------------------------------------------------------------ local disk

type LocalFS struct{}

func (LocalFS) Name() string { return "Local" }

func (LocalFS) Getwd() (string, error) {
	if d, err := os.Getwd(); err == nil {
		return d, nil
	}
	return os.UserHomeDir()
}

func (LocalFS) List(dir string) ([]FileInfo, error) {
	if dir == "" && plat.Drives != nil {
		var out []FileInfo
		for _, d := range plat.Drives() {
			out = append(out, FileInfo{Name: d, Dir: true})
		}
		return out, nil
	}
	des, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	out := make([]FileInfo, 0, len(des))
	for _, de := range des {
		fi := FileInfo{Name: de.Name(), Dir: de.IsDir()}
		if info, err := de.Info(); err == nil {
			fi.Size, fi.Mod = info.Size(), info.ModTime()
			if info.Mode()&os.ModeSymlink != 0 {
				fi.Link = true
				if st, err := os.Stat(filepath.Join(dir, de.Name())); err == nil {
					fi.Dir, fi.Size = st.IsDir(), st.Size()
				}
			}
		}
		out = append(out, fi)
	}
	return out, nil
}

func (LocalFS) Open(p string) (io.ReadCloser, int64, error) {
	f, err := os.Open(p)
	if err != nil {
		return nil, 0, err
	}
	st, err := f.Stat()
	if err != nil {
		f.Close()
		return nil, 0, err
	}
	return f, st.Size(), nil
}

func (LocalFS) Create(p string) (io.WriteCloser, error) { return os.Create(p) }
func (LocalFS) Mkdir(p string) error                    { return os.Mkdir(p, 0o755) }
func (LocalFS) Remove(p string, dir bool) error         { return os.Remove(p) }
func (LocalFS) Rename(a, b string) error                { return os.Rename(a, b) }
func (LocalFS) Join(dir, name string) string {
	if dir == "" {
		return name // a drive such as C:\
	}
	return filepath.Join(dir, name)
}
func (LocalFS) Parent(dir string) string {
	p := filepath.Dir(dir)
	if p == dir && plat.Drives != nil {
		return "" // up from a drive root: the list of drives
	}
	return p
}
func (LocalFS) Close() error { return nil }
