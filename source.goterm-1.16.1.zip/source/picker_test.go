package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestPickerJumpAndFind(t *testing.T) {
	d := t.TempDir()
	for _, n := range []string{"alpha.txt", "apple.ans", "bravo.zip", "Charlie.doc", "delta.bin", "my notes.txt"} {
		os.WriteFile(filepath.Join(d, n), []byte("x"), 0o644)
	}
	os.Mkdir(filepath.Join(d, "docs"), 0o755)
	os.Mkdir(filepath.Join(d, "music"), 0o755)
	a := NewApp(newDefaultConfig())
	p := newPicker("t", d, func(*App, []string) {})
	cur := func() string { return p.Ents[p.Sel].Name }
	key := func(s string) {
		for _, r := range s {
			p.Key(a, KeyEvent{Key: KeyNone, Ch: r})
		}
	}
	key("c")
	if cur() != "Charlie.doc" {
		t.Fatalf("c -> %s", cur())
	}
	p.taAt = p.taAt.Add(-5e9)
	key("a")
	if cur() != "alpha.txt" {
		t.Fatalf("a -> %s", cur())
	}
	p.taAt = p.taAt.Add(-5e9)
	key("a") // repeated letter moves to the next match
	p.taAt = p.taAt.Add(-5e9)
	key("ap")
	if cur() != "apple.ans" {
		t.Fatalf("ap -> %s", cur())
	}
	p.taAt = p.taAt.Add(-5e9)
	key("mu") // a folder
	if cur() != "music" {
		t.Fatalf("m -> %s", cur())
	}
	// Space with nothing typed still marks
	p.taAt = p.taAt.Add(-5e9)
	key("b")
	key("\x20")
	if len(p.Marked) != 0 {
		// 'b' then space within the window is part of the prefix, not a mark
		t.Fatalf("space within a prefix marked a file")
	}
	p.taAt = p.taAt.Add(-5e9)
	p.ta = ""
	key(" ")
	if len(p.Marked) != 1 {
		t.Fatalf("space did not mark: %v", p.Marked)
	}

	// find
	key("/")
	key("TXT")
	var got []string
	for _, e := range p.Ents {
		got = append(got, e.Name)
	}
	if len(p.Ents) != 3 {
		t.Errorf("matches: %v", got)
	}
	for _, e := range p.Ents {
		if e.Name != ".." && !contains(e.Name, "txt") {
			t.Errorf("unexpected match %q", e.Name)
		}
	}
	if cur() != "alpha.txt" {
		t.Errorf("cursor on %q, want first match", cur())
	}
	p.Key(a, KeyEvent{Key: KeyBS})
	p.Key(a, KeyEvent{Key: KeyEsc})
	if p.finding || len(p.Ents) != len(p.all) {
		t.Error("Esc did not clear the filter")
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
