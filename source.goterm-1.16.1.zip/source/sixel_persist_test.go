package main

import (
	"fmt"
	"strings"
	"testing"
	"time"
)

// The Synchronet doors define the palette once and then send palette-less
// dirty boxes with P2=1; the colors must persist between images.
func TestSixelRegistersPersist(t *testing.T) {
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	// frame 1: define register 100 = pure red, paint a 6x6 box
	p.Feed([]byte("\x1b[H\x1bP0;1;0q\"1;1;6;6#100;2;100;0;0#100!6~\x1b\\"))
	// frame 2: no palette, select 100 again, paint elsewhere
	p.Feed([]byte("\x1b[1;3H\x1bP0;1;0q\"1;1;6;6#100!6~\x1b\\"))
	s.ensureGfx()
	st := s.gfxStride()
	for _, pt := range [][2]int{{0, 0}, {2*8 + 1, 0}} {
		if got := s.gfx[pt[1]*st+pt[0]]; got != 0xFFFF0000 {
			t.Errorf("pixel %v = %08x, want red", pt, got)
		}
	}
}

func TestSixelFramePerf(t *testing.T) {
	s := NewScreen(80, 25, 8, 16)
	p := NewParser(s)
	var b strings.Builder
	b.WriteString("\x1b[?80l\x1bP0;1;0q\"1;1;640;384")
	for i := 0; i < 256; i++ {
		fmt.Fprintf(&b, "#%d;2;%d;%d;%d", i, i*100/255, (i*7)%100, (i*13)%100)
	}
	for band := 0; band < 64; band++ {
		for c := 0; c < 8; c++ {
			fmt.Fprintf(&b, "#%d", (band*8+c)%256)
			for x := 0; x < 640; x += 2 {
				b.WriteByte(byte('?' + (x/2+c+band)%64))
				b.WriteByte(byte('?' + (x/2+c+band)%64))
			}
			b.WriteString("$")
		}
		b.WriteString("-")
	}
	b.WriteString("\x1b\\")
	frame := []byte("\x1b[H" + b.String())
	t0 := time.Now()
	n := 30
	for i := 0; i < n; i++ {
		p.Feed(frame)
	}
	per := time.Since(t0) / time.Duration(n)
	t.Logf("%d bytes/frame, %v per frame", len(frame), per)
	if per > 40*time.Millisecond {
		t.Errorf("sixel frame too slow: %v", per)
	}
}
