package main

import (
	"os"
	"testing"
)

func BenchmarkJXLDoom(b *testing.B) {
	data, _ := os.ReadFile("testdata/jxl_doom_d2.jxl")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := decodeJXL(data); err != nil {
			b.Fatal(err)
		}
	}
}
